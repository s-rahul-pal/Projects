package com.onboarding.partner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PartnerApplicationTests {

	@Test
	void contextLoads() {
	}

}
