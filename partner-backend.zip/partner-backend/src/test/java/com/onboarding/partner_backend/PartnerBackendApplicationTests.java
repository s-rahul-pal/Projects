package com.onboarding.partner_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PartnerBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
