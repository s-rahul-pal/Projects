package com.onboarding.partner_backend.util;

import com.onboarding.partner_backend.model.Partner;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.*;
import java.util.Arrays;
import java.util.List;

@Component
public class ExcelWriter {

    @Value("${excel.file-path}")
    private String excelFilePath;

    private static final List<String> HEADERS = Arrays.asList(
            "Partner Name", "Sold To", "Ship To", "Technical Contact Details", "Business Contact Details","TE Counterpart Contact Details", "isEnvironmentSame", "Protocol", "EDI Standard",
            "EDI ID", "ISA Qualifier", "GS ID", "UNB Qualifier", "Other File Format",
            "Plant ID", "Transaction Type", "Transaction Version", "Vendor ID", "Specification Path", "Remarks",
            "AS2 ID", "Endpoint", "SSL", "Payload Type", "Encryption Algo",
            "Signing Algo", "MDN Mode", "SFTP Host", "SFTP Port", "SFTP Username",
            "SFTP Auth Type", "SFTP Directory", "SFTP Password",
            "OFTP2 SSID", "OFTP2 SFID", "OFTP2 Password", "OFTP2 Host", "OFTP2 Port",
            "Other Protocol Description",
            // QA Fields
            "QA Protocol", "QA EDI Standard", "QA EDI ID",
            "QA ISA Qualifier", "QA GS ID", "QA UNB Qualifier","Other QA File Format",
            "QA Plant ID", "QA Transaction Type", "QA Transaction Version", "QA Vendor ID", "QA Remarks",
            "QA AS2 ID", "QA Endpoint", "QA SSL", "QA Payload Type", "QA Encryption Algo",
            "QA Signing Algo", "QA MDN Mode", "QA SFTP Host", "QA SFTP Port", "QA SFTP Username",
            "QA SFTP Auth Type", "QA SFTP Directory", "QA SFTP Password",
            "QA OFTP2 SSID", "QA OFTP2 SFID", "QA OFTP2 Password", "QA OFTP2 Host", "QA OFTP2 Port",
            "QA Other Protocol Description"
    );

    public void writePartner(Partner partner) {
        File file = new File(excelFilePath+"/partners_parameter_sheet.xlsx");
        Workbook workbook;
        Sheet sheet;
        boolean isNewFile = !file.exists();

        try (FileInputStream fis = isNewFile ? null : new FileInputStream(file)) {
            workbook = isNewFile ? new XSSFWorkbook() : new XSSFWorkbook(fis);
            sheet = workbook.getSheet("Partners");

            if (sheet == null) {
                sheet = workbook.createSheet("Partners");
            }

            if (isNewFile || sheet.getPhysicalNumberOfRows() == 0) {
                writeHeaderRow(sheet);
            }

            int rowIndex = findRowIndex(sheet, partner.getSoldTo(), partner.getProtocol(), partner.getEdiId());
            Row row = (rowIndex >= 0) ? sheet.getRow(rowIndex) : sheet.createRow(sheet.getLastRowNum() + 1);

            writePartnerToRow(partner, row);

            try (FileOutputStream fos = new FileOutputStream(file)) {
                workbook.write(fos);
            }

            workbook.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    //Adding method for creating excel sheet inside the partner's directory
    public void writeInsidePartner(Partner partner) {

        File file = new File(excelFilePath+"/"+partner.getPartnerName()+"/"+partner.getPartnerName()+"_parameter_Sheet.xlsx");
        Workbook workbook;
        Sheet sheet;
        boolean isNewFile = !file.exists();

        try (FileInputStream fis = isNewFile ? null : new FileInputStream(file)) {
            workbook = isNewFile ? new XSSFWorkbook() : new XSSFWorkbook(fis);
            sheet = workbook.getSheet("Partners");

            if (sheet == null) {
                sheet = workbook.createSheet("Partners");
            }

            if (isNewFile || sheet.getPhysicalNumberOfRows() == 0) {
                writeHeaderRow(sheet);
            }

            int rowIndex = findRowIndex(sheet, partner.getPartnerName(), partner.getProtocol(), partner.getEdiId());
            Row row = (rowIndex >= 0) ? sheet.getRow(rowIndex) : sheet.createRow(sheet.getLastRowNum() + 1);

            writePartnerToRow(partner, row);

            try (FileOutputStream fos = new FileOutputStream(file)) {
                workbook.write(fos);
            }

            workbook.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private void writeHeaderRow(Sheet sheet) {
        Row header = sheet.createRow(0);
        for (int i = 0; i < HEADERS.size(); i++) {
            Cell cell = header.createCell(i);
            cell.setCellValue(HEADERS.get(i));
        }
    }

    private void writePartnerToRow(Partner partner, Row row) {
        int i = 0;
        row.createCell(i++).setCellValue(defaultStr(partner.getPartnerName()));
        row.createCell(i++).setCellValue(defaultStr(partner.getSoldTo()));
        row.createCell(i++).setCellValue(defaultStr(partner.getShipTo()));
        row.createCell(i++).setCellValue(defaultStr(partner.getTechnicalContactDetails()));
        row.createCell(i++).setCellValue(defaultStr(partner.getBusinessContactDetails()));
        row.createCell(i++).setCellValue(defaultStr(partner.getTeCounterpartContactDetails()));
        row.createCell(i++).setCellValue(defaultStr(partner.getIsEnvSame()));
        row.createCell(i++).setCellValue(defaultStr(partner.getProtocol()));
        row.createCell(i++).setCellValue(defaultStr(partner.getEdiStandard()));
        row.createCell(i++).setCellValue(defaultStr(partner.getEdiId()));

        row.createCell(i++).setCellValue(defaultStr(partner.getIsaIdQualifier()));
        row.createCell(i++).setCellValue(defaultStr(partner.getGsId()));
        row.createCell(i++).setCellValue(defaultStr(partner.getUnbIdQualifier()));
        row.createCell(i++).setCellValue(defaultStr(partner.getOtherFileFormat()));
        row.createCell(i++).setCellValue(defaultStr(partner.getPlantId()));
        row.createCell(i++).setCellValue(defaultStr(partner.getTransactionType()));
        row.createCell(i++).setCellValue(defaultStr(partner.getTransactionVersion()));
        row.createCell(i++).setCellValue(defaultStr(partner.getVendorId()));
        row.createCell(i++).setCellValue(defaultStr(partner.getSpecPath()));
        row.createCell(i++).setCellValue(defaultStr(partner.getRemarksDescription()));

        // AS2 Fields
        row.createCell(i++).setCellValue(defaultStr(partner.getAs2Id()));
        row.createCell(i++).setCellValue(defaultStr(partner.getEndpoint()));
        row.createCell(i++).setCellValue(defaultStr(partner.getSsl()));
        row.createCell(i++).setCellValue(defaultStr(partner.getPayloadType()));
        row.createCell(i++).setCellValue(defaultStr(partner.getEncryptionAlgo()));
        row.createCell(i++).setCellValue(defaultStr(partner.getSigningAlgo()));
        row.createCell(i++).setCellValue(defaultStr(partner.getMdnMode()));

        // SFTP Fields
        row.createCell(i++).setCellValue(defaultStr(partner.getSftpHost()));
        row.createCell(i++).setCellValue(defaultStr(partner.getSftpPort()));
        row.createCell(i++).setCellValue(defaultStr(partner.getUsername()));
        row.createCell(i++).setCellValue(defaultStr(partner.getAuthType()));
        row.createCell(i++).setCellValue(defaultStr(partner.getDirectory()));
        row.createCell(i++).setCellValue(defaultStr(partner.getSftpPassword()));

        // OFTP2 Fields
        row.createCell(i++).setCellValue(defaultStr(partner.getSsid()));
        row.createCell(i++).setCellValue(defaultStr(partner.getSfid()));
        row.createCell(i++).setCellValue(defaultStr(partner.getOftpPassword()));
        row.createCell(i++).setCellValue(defaultStr(partner.getHost()));
        row.createCell(i++).setCellValue(defaultStr(partner.getPort()));
        // Other Protocol
        row.createCell(i++).setCellValue(defaultStr(partner.getOtherProtocol()));

        //QA Fields

        row.createCell(i++).setCellValue(defaultStr(partner.getQaProtocol()));
        row.createCell(i++).setCellValue(defaultStr(partner.getQaEdiStandard()));
        row.createCell(i++).setCellValue(defaultStr(partner.getQaEdiId()));
        row.createCell(i++).setCellValue(defaultStr(partner.getQaIsaIdQualifier()));
        row.createCell(i++).setCellValue(defaultStr(partner.getQaGsId()));
        row.createCell(i++).setCellValue(defaultStr(partner.getQaUnbIdQualifier()));
        row.createCell(i++).setCellValue(defaultStr(partner.getQaOtherFileFormat()));
        row.createCell(i++).setCellValue(defaultStr(partner.getQaPlantId()));
        row.createCell(i++).setCellValue(defaultStr(partner.getQaTransactionType()));
        row.createCell(i++).setCellValue(defaultStr(partner.getQaTransactionVersion()));
        row.createCell(i++).setCellValue(defaultStr(partner.getQaVendorId()));
        row.createCell(i++).setCellValue(defaultStr(partner.getQaRemarksDescription()));

        // AS2 Fields
        row.createCell(i++).setCellValue(defaultStr(partner.getQaAs2Id()));
        row.createCell(i++).setCellValue(defaultStr(partner.getQaEndpoint()));
        row.createCell(i++).setCellValue(defaultStr(partner.getQaSsl()));
        row.createCell(i++).setCellValue(defaultStr(partner.getQaPayloadType()));
        row.createCell(i++).setCellValue(defaultStr(partner.getQaEncryptionAlgo()));
        row.createCell(i++).setCellValue(defaultStr(partner.getQaSigningAlgo()));
        row.createCell(i++).setCellValue(defaultStr(partner.getQaMdnMode()));

        // SFTP Fields
        row.createCell(i++).setCellValue(defaultStr(partner.getQaSftpHost()));
        row.createCell(i++).setCellValue(defaultStr(partner.getQaSftpPort()));
        row.createCell(i++).setCellValue(defaultStr(partner.getQaUsername()));
        row.createCell(i++).setCellValue(defaultStr(partner.getQaAuthType()));
        row.createCell(i++).setCellValue(defaultStr(partner.getQaDirectory()));
        row.createCell(i++).setCellValue(defaultStr(partner.getQaSftpPassword()));

        // OFTP2 Fields
        row.createCell(i++).setCellValue(defaultStr(partner.getQaSsid()));
        row.createCell(i++).setCellValue(defaultStr(partner.getQaSfid()));
        row.createCell(i++).setCellValue(defaultStr(partner.getQaOftp2Password()));
        row.createCell(i++).setCellValue(defaultStr(partner.getQaHost()));
        row.createCell(i++).setCellValue(defaultStr(partner.getQaPort()));
        // Other Protocol
        row.createCell(i++).setCellValue(defaultStr(partner.getQaOtherProtocol()));
    }

    private int findRowIndex(Sheet sheet, String partnerName, String protocol, String ediId) {
        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);
            if (row != null) {
                Cell codeCell = row.getCell(1); // Sold To
                Cell protocolCell = row.getCell(7); // Protocol
                Cell ediIdCell = row.getCell(8); // EDI ID

                if (codeCell != null && protocolCell != null && ediIdCell != null &&
                        codeCell.getStringCellValue().equalsIgnoreCase(partnerName) &&
                        protocolCell.getStringCellValue().equalsIgnoreCase(protocol) && ediIdCell.getStringCellValue().equalsIgnoreCase(ediId)) {
                    return i;
                }
            }
        }
        return -1;
    }

    private String defaultStr(String val) {
        return (val != null) ? val : "";
    }
}