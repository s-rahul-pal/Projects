package com.onboarding.partner_backend.model;

import jakarta.persistence.*;


@Entity
public class Partner {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String partnerName;
    private String soldTo;
    private String shipTo;
    private String technicalContactDetails;
    private String businessContactDetails;
    private String teCounterpartContactDetails;



    private String protocol; // AS2, SFTP, OFTP2
    private String isEnvSame;
    private String SpecPath; // file upload directory
    private String ediStandard; // ANSI-X12, EDIFACT, VDA
    // QA
    private String qaEdiStandard;
    private String qaProtocol;


    // ANSI-X12 params
    private String gsId;
    private String isaIdQualifier;

    // QA
    private String qaGsId;
    private String qaIsaIdQualifier;


    // EDIFACT params

    private String unbIdQualifier;
    // QA
    private String qaUnbIdQualifier;

    // Other EDI standard
    private String otherFileFormat;
    //QA
    private String qaOtherFileFormat;

    //Common parameters
    private String ediId;   // ISA ID, UNB ID, VDA ID
    private String transactionType;
    private String transactionVersion;
    private String vendorId;
    private String plantId;
    private String remarksDescription;

    //QA
    private String qaEdiId;
    private String qaVendorId;
    private String qaTransactionType;
    private String qaTransactionVersion;
    private String qaPlantId;
    private String qaRemarksDescription;

    // AS2 partner details

    private String as2Id;
    private String endpoint;
    private String ssl;
    private String payloadType;
    private String encryptionAlgo;
    private String signingAlgo;
    private String mdnMode;
    private String exchangeCertPath;
    private String signingCertPath;
    private String sslCertPath;

    //QA AS2 partner
    private String qaAs2Id;
    private String qaEndpoint;
    private String qaSsl;
    private String qaPayloadType;
    private String qaEncryptionAlgo;
    private String qaSigningAlgo;
    private String qaMdnMode;

    // OFTP2 partner details
    private String ssid;
    private String sfid;
    private String oftpPassword;
    private String host;
    private String port;
    private String oftpCertPath;
    // QA
    private String qaSsid;
    private String qaSfid;
    private String qaOftp2Password;
    private String qaHost;
    private String qaPort;


    // SFTP partner details

    private String sftpHost;
    private String sftpPort;
    private String username;
    private String authType;
    private String sftpPassword;
    private String directory;
    // QA
    private String qaSftpHost;
    private String qaSftpPort;
    private String qaUsername;
    private String qaAuthType;
    private String qaSftpPassword;
    private String qaDirectory;

    // Other protocol
    private String otherProtocol;

    // Qa
    private String qaOtherProtocol;

    public String getTechnicalContactDetails() {
        return technicalContactDetails;
    }

    public void setTechnicalContactDetails(String technicalContactDetails) {
        this.technicalContactDetails = technicalContactDetails;
    }

    public String getBusinessContactDetails() {
        return businessContactDetails;
    }

    public void setBusinessContactDetails(String businessContactDetails) {
        this.businessContactDetails = businessContactDetails;
    }

    public String getTeCounterpartContactDetails() {
        return teCounterpartContactDetails;
    }

    public void setTeCounterpartContactDetails(String teCounterpartContactDetails) {
        this.teCounterpartContactDetails = teCounterpartContactDetails;
    }

    public String getQaEdiId() {
        return qaEdiId;
    }

    public void setQaEdiId(String qaEdiId) {
        this.qaEdiId = qaEdiId;
    }

    public String getEdiId() {
        return ediId;
    }

    public void setEdiId(String ediId) {
        this.ediId = ediId;
    }

    public String getQaRemarksDescription() {
        return qaRemarksDescription;
    }

    public void setQaRemarksDescription(String qaRemarksDescription) {
        this.qaRemarksDescription = qaRemarksDescription;
    }

    public String getSoldTo() {
        return soldTo;
    }

    public void setSoldTo(String soldTo) {
        this.soldTo = soldTo;
    }

    public String getShipTo() {
        return shipTo;
    }

    public void setShipTo(String shipTo) {
        this.shipTo = shipTo;
    }

    public String getTransactionVersion() {
        return transactionVersion;
    }

    public void setTransactionVersion(String transactionVersion) {
        this.transactionVersion = transactionVersion;
    }

    public String getOtherFileFormat() {
        return otherFileFormat;
    }

    public void setOtherFileFormat(String otherFileFormat) {
        this.otherFileFormat = otherFileFormat;
    }

    public String getQaOtherFileFormat() {
        return qaOtherFileFormat;
    }

    public void setQaOtherFileFormat(String qaOtherFileFormat) {
        this.qaOtherFileFormat = qaOtherFileFormat;
    }

    public String getPlantId() {
        return plantId;
    }

    public void setPlantId(String plantId) {
        this.plantId = plantId;
    }

    public String getRemarksDescription() {
        return remarksDescription;
    }

    public void setRemarksDescription(String remarksDescription) {
        this.remarksDescription = remarksDescription;
    }

    public String getQaPlantId() {
        return qaPlantId;
    }

    public void setQaPlantId(String qaPlantId) {
        this.qaPlantId = qaPlantId;
    }

    public String getOtherProtocol() {
        return otherProtocol;
    }

    public void setOtherProtocol(String otherProtocol) {
        this.otherProtocol = otherProtocol;
    }

    public String getQaOtherProtocol() {
        return qaOtherProtocol;
    }

    public void setQaOtherProtocol(String qaOtherProtocol) {
        this.qaOtherProtocol = qaOtherProtocol;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPartnerName() {
        return partnerName;
    }

    public void setPartnerName(String partnerName) {
        this.partnerName = partnerName;
    }



    public String getProtocol() {
        return protocol;
    }

    public void setProtocol(String protocol) {
        this.protocol = protocol;
    }

    public String getIsEnvSame() {
        return isEnvSame;
    }

    public void setIsEnvSame(String isEnvSame) {
        this.isEnvSame = isEnvSame;
    }

    public String getSpecPath() {
        return SpecPath;
    }

    public void setSpecPath(String specPath) {
        SpecPath = specPath;
    }

    public String getEdiStandard() {
        return ediStandard;
    }

    public void setEdiStandard(String ediStandard) {
        this.ediStandard = ediStandard;
    }

    public String getQaEdiStandard() {
        return qaEdiStandard;
    }

    public void setQaEdiStandard(String qaEdiStandard) {
        this.qaEdiStandard = qaEdiStandard;
    }

    public String getQaProtocol() {
        return qaProtocol;
    }

    public void setQaProtocol(String qaProtocol) {
        this.qaProtocol = qaProtocol;
    }


    public String getGsId() {
        return gsId;
    }

    public void setGsId(String gsId) {
        this.gsId = gsId;
    }

    public String getIsaIdQualifier() {
        return isaIdQualifier;
    }

    public void setIsaIdQualifier(String isaIdQualifier) {
        this.isaIdQualifier = isaIdQualifier;
    }


    public String getQaGsId() {
        return qaGsId;
    }

    public void setQaGsId(String qaGsId) {
        this.qaGsId = qaGsId;
    }

    public String getQaIsaIdQualifier() {
        return qaIsaIdQualifier;
    }

    public void setQaIsaIdQualifier(String qaIsaIdQualifier) {
        this.qaIsaIdQualifier = qaIsaIdQualifier;
    }


    public String getUnbIdQualifier() {
        return unbIdQualifier;
    }

    public void setUnbIdQualifier(String unbIdQualifier) {
        this.unbIdQualifier = unbIdQualifier;
    }


    public String getQaUnbIdQualifier() {
        return qaUnbIdQualifier;
    }

    public void setQaUnbIdQualifier(String qaUnbIdQualifier) {
        this.qaUnbIdQualifier = qaUnbIdQualifier;
    }



    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public String getVendorId() {
        return vendorId;
    }

    public void setVendorId(String vendorId) {
        this.vendorId = vendorId;
    }

    public String getQaVendorId() {
        return qaVendorId;
    }

    public void setQaVendorId(String qaVendorId) {
        this.qaVendorId = qaVendorId;
    }

    public String getQaTransactionType() {
        return qaTransactionType;
    }

    public void setQaTransactionType(String qaTransactionType) {
        this.qaTransactionType = qaTransactionType;
    }

    public String getAs2Id() {
        return as2Id;
    }

    public void setAs2Id(String as2Id) {
        this.as2Id = as2Id;
    }

    public String getEndpoint() {
        return endpoint;
    }

    public void setEndpoint(String endpoint) {
        this.endpoint = endpoint;
    }

    public String getSsl() {
        return ssl;
    }

    public void setSsl(String ssl) {
        this.ssl = ssl;
    }

    public String getPayloadType() {
        return payloadType;
    }

    public void setPayloadType(String payloadType) {
        this.payloadType = payloadType;
    }

    public String getEncryptionAlgo() {
        return encryptionAlgo;
    }

    public void setEncryptionAlgo(String encryptionAlgo) {
        this.encryptionAlgo = encryptionAlgo;
    }

    public String getSigningAlgo() {
        return signingAlgo;
    }

    public void setSigningAlgo(String signingAlgo) {
        this.signingAlgo = signingAlgo;
    }

    public String getMdnMode() {
        return mdnMode;
    }

    public void setMdnMode(String mdnMode) {
        this.mdnMode = mdnMode;
    }

    public String getExchangeCertPath() {
        return exchangeCertPath;
    }

    public void setExchangeCertPath(String exchangeCertPath) {
        this.exchangeCertPath = exchangeCertPath;
    }

    public String getSigningCertPath() {
        return signingCertPath;
    }

    public void setSigningCertPath(String signingCertPath) {
        this.signingCertPath = signingCertPath;
    }

    public String getSslCertPath() {
        return sslCertPath;
    }

    public void setSslCertPath(String sslCertPath) {
        this.sslCertPath = sslCertPath;
    }

    public String getQaAs2Id() {
        return qaAs2Id;
    }

    public void setQaAs2Id(String qaAs2Id) {
        this.qaAs2Id = qaAs2Id;
    }

    public String getQaEndpoint() {
        return qaEndpoint;
    }

    public void setQaEndpoint(String qaEndpoint) {
        this.qaEndpoint = qaEndpoint;
    }

    public String getQaSsl() {
        return qaSsl;
    }

    public void setQaSsl(String qaSsl) {
        this.qaSsl = qaSsl;
    }

    public String getQaPayloadType() {
        return qaPayloadType;
    }

    public void setQaPayloadType(String qaPayloadType) {
        this.qaPayloadType = qaPayloadType;
    }

    public String getQaEncryptionAlgo() {
        return qaEncryptionAlgo;
    }

    public void setQaEncryptionAlgo(String qaEncryptionAlgo) {
        this.qaEncryptionAlgo = qaEncryptionAlgo;
    }

    public String getQaSigningAlgo() {
        return qaSigningAlgo;
    }

    public void setQaSigningAlgo(String qaSigningAlgo) {
        this.qaSigningAlgo = qaSigningAlgo;
    }

    public String getQaMdnMode() {
        return qaMdnMode;
    }

    public void setQaMdnMode(String qaMdnMode) {
        this.qaMdnMode = qaMdnMode;
    }

    public String getSsid() {
        return ssid;
    }

    public void setSsid(String ssid) {
        this.ssid = ssid;
    }

    public String getSfid() {
        return sfid;
    }

    public void setSfid(String sfid) {
        this.sfid = sfid;
    }

    public String getOftpPassword() {
        return oftpPassword;
    }

    public void setOftpPassword(String oftpPassword) {
        this.oftpPassword = oftpPassword;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public String getOftpCertPath() {
        return oftpCertPath;
    }

    public void setOftpCertPath(String oftpCertPath) {
        this.oftpCertPath = oftpCertPath;
    }

    public String getQaSsid() {
        return qaSsid;
    }

    public void setQaSsid(String qaSsid) {
        this.qaSsid = qaSsid;
    }

    public String getQaSfid() {
        return qaSfid;
    }

    public void setQaSfid(String qaSfid) {
        this.qaSfid = qaSfid;
    }

    public String getQaOftp2Password() {
        return qaOftp2Password;
    }

    public void setQaOftp2Password(String qaOftp2Password) {
        this.qaOftp2Password = qaOftp2Password;
    }

    public String getQaHost() {
        return qaHost;
    }

    public void setQaHost(String qaHost) {
        this.qaHost = qaHost;
    }

    public String getQaPort() {
        return qaPort;
    }

    public void setQaPort(String qaPort) {
        this.qaPort = qaPort;
    }

    public String getSftpHost() {
        return sftpHost;
    }

    public void setSftpHost(String sftpHost) {
        this.sftpHost = sftpHost;
    }

    public String getSftpPort() {
        return sftpPort;
    }

    public void setSftpPort(String sftpPort) {
        this.sftpPort = sftpPort;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getAuthType() {
        return authType;
    }

    public void setAuthType(String authType) {
        this.authType = authType;
    }

    public String getSftpPassword() {
        return sftpPassword;
    }

    public void setSftpPassword(String sftpPassword) {
        this.sftpPassword = sftpPassword;
    }

    public String getDirectory() {
        return directory;
    }

    public void setDirectory(String directory) {
        this.directory = directory;
    }

    public String getQaSftpHost() {
        return qaSftpHost;
    }

    public void setQaSftpHost(String qaSftpHost) {
        this.qaSftpHost = qaSftpHost;
    }

    public String getQaSftpPort() {
        return qaSftpPort;
    }

    public void setQaSftpPort(String qaSftpPort) {
        this.qaSftpPort = qaSftpPort;
    }

    public String getQaUsername() {
        return qaUsername;
    }

    public void setQaUsername(String qaUsername) {
        this.qaUsername = qaUsername;
    }

    public String getQaAuthType() {
        return qaAuthType;
    }

    public void setQaAuthType(String qaAuthType) {
        this.qaAuthType = qaAuthType;
    }

    public String getQaSftpPassword() {
        return qaSftpPassword;
    }

    public void setQaSftpPassword(String qaSftpPassword) {
        this.qaSftpPassword = qaSftpPassword;
    }

    public String getQaDirectory() {
        return qaDirectory;
    }

    public void setQaDirectory(String qaDirectory) {
        this.qaDirectory = qaDirectory;
    }

    public String getQaTransactionVersion() {
        return qaTransactionVersion;
    }

    public void setQaTransactionVersion(String qaTransactionVersion) {
        this.qaTransactionVersion = qaTransactionVersion;
    }
}
