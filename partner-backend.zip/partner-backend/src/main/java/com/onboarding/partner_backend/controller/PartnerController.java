package com.onboarding.partner_backend.controller;

import com.onboarding.partner_backend.service.PartnerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;


import java.util.Map;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/partner")
public class PartnerController {

    @Autowired
    private PartnerService partnerService;

    @PostMapping
    public ResponseEntity<String> savePartner(
            @RequestParam Map<String, String> params,
            @RequestParam(value = "specPath", required = false) MultipartFile[] specFiles,
            @RequestParam(value = "qaSpecPath", required = false) MultipartFile[] qaSpecFiles,
            @RequestParam(value = "samplePath", required = false) MultipartFile[] sampleFiles,
            @RequestParam(value = "qaSamplePath", required = false) MultipartFile[] qaSampleFiles,
            @RequestParam(required = false) Map<String, MultipartFile> files) {

        try {
            String response = partnerService.savePartner(params, specFiles, qaSpecFiles, sampleFiles, qaSampleFiles, files);
            System.out.println(params.get("envSame"));
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.internalServerError().body("Error saving partner: " + e.getMessage());
        }
    }
}