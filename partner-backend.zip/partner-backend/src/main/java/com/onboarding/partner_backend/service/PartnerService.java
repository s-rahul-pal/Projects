package com.onboarding.partner_backend.service;

import com.onboarding.partner_backend.model.Partner;
import com.onboarding.partner_backend.repository.PartnerRepository;
import com.onboarding.partner_backend.util.ExcelWriter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Map;
import java.util.Optional;

@Service
public class PartnerService {

    private final PartnerRepository partnerRepository;
    private final ExcelWriter excelWriter;

    @Value("${file.upload-dir}")
    private String uploadDir;

    public PartnerService(PartnerRepository partnerRepository, ExcelWriter excelWriter) {
        this.partnerRepository = partnerRepository;
        this.excelWriter = excelWriter;
    }

    public String savePartner(Map<String, String> params,
                              MultipartFile[] specFiles,
                              MultipartFile[] qaSpecFiles,
                              MultipartFile[] sampleFiles,
                              MultipartFile[] qaSampleFiles,
                              Map<String, MultipartFile> files) throws IOException {

        String partnerName = params.get("partnerName");
        String soldTo = params.get("soldTo");
        String protocol = params.get("protocol");

        String ediId = Optional.ofNullable(params.get("isaId"))
                .orElse(Optional.ofNullable(params.get("unbId"))
                        .orElse(params.getOrDefault("vdaId", "")));

        Partner partner = partnerRepository
                .findBySoldToAndProtocolAndEdiId( soldTo, protocol, ediId)
                .orElse(new Partner());

        // Set values from params to Partner object
        setPartnerData(partner, params, ediId, files);

        // Save files
        String sanitizedPartnerName = partnerName != null ? partnerName.replaceAll("[^a-zA-Z0-9-_]", "_") : "unknown_partner";
        Path partnerDir = Paths.get(uploadDir, sanitizedPartnerName);
        Files.createDirectories(partnerDir);

        handleMultipleFiles(partner, partnerDir, specFiles, qaSpecFiles, "specificationFile", true);
        handleMultipleFiles(partner, partnerDir, sampleFiles, qaSampleFiles, "sampleFiles", false);
        saveAdditionalFiles(files, partnerName, partner);

        partnerRepository.save(partner);
        excelWriter.writePartner(partner);
        excelWriter.writeInsidePartner(partner);

        return "Partner saved successfully.";
    }

    private void setPartnerData(Partner partner, Map<String, String> params, String ediId, Map<String, MultipartFile> files) throws IOException {
        partner.setPartnerName(params.get("partnerName"));
        partner.setSoldTo(params.get("soldTo"));
        partner.setShipTo(params.get("shipTo"));
        partner.setTechnicalContactDetails(params.get("technicalContactDetails"));
        partner.setBusinessContactDetails(params.get("businessContactDetails"));
        partner.setTeCounterpartContactDetails(params.get("teCounterpartContactDetails"));
        partner.setProtocol(params.get("protocol"));
        partner.setIsEnvSame(("AS2".equalsIgnoreCase(params.get("QAprotocol"))
                || "OFTP2".equalsIgnoreCase(params.get("QAprotocol"))
                || "SFTP".equalsIgnoreCase(params.get("QAprotocol"))
                || "Others".equalsIgnoreCase(params.get("QAprotocol"))) ? "No" : "Yes");

        partner.setEdiStandard(params.get("specification"));
        partner.setPlantId(params.get("customerPlantId"));
        partner.setEdiId(ediId);
        partner.setIsaIdQualifier(params.get("isaIdQualifier"));
        partner.setGsId(params.get("gsId"));
        partner.setTransactionType(params.get("transactionTypes"));
        partner.setTransactionVersion(params.get("transactionVersion"));
        partner.setVendorId(params.get("vendorId"));
        partner.setUnbIdQualifier(params.get("unbIdQualifier"));
        partner.setOtherFileFormat(params.get("fileFormat"));
        partner.setRemarksDescription(params.get("remarksDescription"));

        partner.setQaProtocol(params.get("QAprotocol"));
        partner.setQaEdiStandard(params.get("QAediStandard"));
        partner.setQaPlantId(params.get("QACustomerPlantId"));
        partner.setQaEdiId(Optional.ofNullable(params.get("QAisaId"))
                .orElse(Optional.ofNullable(params.get("QAunbId"))
                        .orElse(params.get("QAvdaId"))));
        partner.setQaIsaIdQualifier(params.get("QAisaIdQualifier"));
        partner.setQaGsId(params.get("QAgsId"));
        partner.setQaTransactionType(params.get("QAtransactionTypes"));
        partner.setQaTransactionVersion(params.get("QAtransactionVersion"));
        partner.setQaVendorId(params.get("QAvendorId"));
        partner.setQaUnbIdQualifier(params.get("QAunbIdQualifier"));
        partner.setQaOtherFileFormat(params.get("QAfileFormat"));
        partner.setQaRemarksDescription(params.get("QARemarksDescription"));

        partner.setAs2Id(params.get("as2Id"));
        partner.setEndpoint(params.get("endpoint"));
        partner.setSsl(params.get("ssl"));
        partner.setPayloadType(params.get("payloadType"));
        partner.setEncryptionAlgo(params.get("encryptionAlgo"));
        partner.setSigningAlgo(params.get("signingAlgo"));
        partner.setMdnMode(params.get("mdnMode"));
        partner.setQaAs2Id(params.get("QAas2Id"));
        partner.setQaEndpoint(params.get("QAendpoint"));
        partner.setQaSsl(params.get("QAssl"));
        partner.setQaPayloadType(params.get("QApayloadType"));
        partner.setQaEncryptionAlgo(params.get("QAencryptionAlgo"));
        partner.setQaSigningAlgo(params.get("QAsigningAlgo"));
        partner.setQaMdnMode(params.get("QAmdnMode"));

        // SFTP, OFTP2, Others - handle separately below...
        partner.setSftpHost(params.get("sftphost"));

        partner.setUsername(params.get("username"));
        partner.setAuthType(params.get("authType"));
        partner.setDirectory(params.get("directory"));
        partner.setSftpPassword(params.get("sftpPassword"));
        partner.setQaSftpHost(params.get("QAsftphost"));
        partner.setQaUsername(params.get("QAusername"));
        partner.setQaAuthType(params.get("QAauthType"));
        partner.setQaDirectory(params.get("QAdirectory"));
        partner.setQaSftpPassword(params.get("QAsftpPassword"));

        if(partner.getProtocol().equalsIgnoreCase("OFTP2")){
            partner.setPort(params.get("port"));
        }else {
            partner.setSftpPort(params.get("port"));
        }
        if(partner.getQaProtocol().equalsIgnoreCase("OFTP2")){
            partner.setQaPort(params.get("port"));
        }else {
            partner.setQaSftpPort(params.get("QAport"));
        }
        partner.setSsid(params.get("ssid"));
        partner.setSfid(params.get("sfid"));
        partner.setOftpPassword(params.get("oftp2Password"));
        partner.setHost(params.get("host"));




        partner.setQaSsid(params.get("QAssid"));
        partner.setQaSfid(params.get("QAsfid"));
        partner.setQaOftp2Password(params.get("QAoftp2Password"));
        partner.setQaHost(params.get("QAhost"));
        partner.setOtherProtocol(params.get("otherProtocolDescription"));
        partner.setQaOtherProtocol(params.get("QAOtherProtocolDescription"));
    }

    private void handleMultipleFiles(Partner partner, Path baseDir,
                                     MultipartFile[] files, MultipartFile[] qaFiles,
                                     String folderName, boolean setPathToPartner) throws IOException {
        if ((files != null && files.length > 0) || (qaFiles != null && qaFiles.length > 0)) {
            Path folderPath = baseDir.resolve(folderName);
            Files.createDirectories(folderPath);

            if (files != null) {
                for (MultipartFile file : files) {
                    if (file != null && !file.isEmpty()) {
                        Path filePath = folderPath.resolve(System.currentTimeMillis() + "_" + file.getOriginalFilename());
                        Files.write(filePath, file.getBytes());
                    }
                }
            }

            if (qaFiles != null) {
                for (MultipartFile file : qaFiles) {
                    if (file != null && !file.isEmpty()) {
                        Path filePath = folderPath.resolve(System.currentTimeMillis() + "_QA_" + file.getOriginalFilename());
                        Files.write(filePath, file.getBytes());
                    }
                }
            }

            if (setPathToPartner) {
                partner.setSpecPath(folderPath.toString());
            }
        }
    }

    private void saveAdditionalFiles(Map<String, MultipartFile> files, String partnerName, Partner partner) throws IOException {
        if (files == null) return;

        partner.setExchangeCertPath(saveFile(files.get("exchangeCert"), "trusted", partnerName));
        partner.setSigningCertPath(saveFile(files.get("signingCert"), "trusted", partnerName));
        partner.setSslCertPath(saveFile(files.get("sslCert"), "SSL", partnerName));
        partner.setOftpCertPath(saveFile(files.get("oftp2Cert"), "SSL", partnerName));

        saveFile(files.get("QAexchangeCert"), "QAtrusted", partnerName);
        saveFile(files.get("QAsigningCert"), "QAtrusted", partnerName);
        saveFile(files.get("QAsslCert"), "QA_SSL", partnerName);
        saveFile(files.get("QAoftp2Cert"), "QA_SSL", partnerName);
        saveFile(files.get("remarksFile"), "Remarks_", partnerName);
        saveFile(files.get("QAremarksFile"), "QA_Remarks_", partnerName);
        saveFile(files.get("connectivityDetails"), "OtherProtocol_", partnerName);
        saveFile(files.get("QAconnectivityDetails"), "QA_OtherProtocol_", partnerName);
    }

    private String saveFile(MultipartFile file, String type, String partnerName) throws IOException {
        if (file == null || file.isEmpty()) return null;
        String sanitizedPartnerName = partnerName.replaceAll("[^a-zA-Z0-9-_]", "_");
        Path dir = Paths.get(uploadDir, sanitizedPartnerName);
        Files.createDirectories(dir);
        String fileName = System.currentTimeMillis() + "_" + type + "_" + file.getOriginalFilename();
        Path filePath = dir.resolve(fileName);
        Files.write(filePath, file.getBytes());
        return filePath.toString();
    }
}