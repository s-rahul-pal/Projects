package com.te.DashboardTracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DashboardTrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DashboardTrackerApplication.class, args);
	}

}
