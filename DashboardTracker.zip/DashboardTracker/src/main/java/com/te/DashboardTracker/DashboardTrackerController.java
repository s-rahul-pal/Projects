package com.te.DashboardTracker;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardTrackerController {

    @Autowired
    private DashboardTrackerRepository repository;

    @GetMapping
    public List<DashboardTracker> getRecords(
            @RequestParam(required = false) String intSenderId,
            @RequestParam(required = false) String intReceiverId,
            @RequestParam(required = false) String idocNumber,
            @RequestParam(required = false) String referenceNumber,
            @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss") Date from,
            @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss") Date to
    ) {
        Optional<DashboardTracker> opt = repository.findByIdocNumber(idocNumber);
        List<DashboardTracker> idoc = opt.stream().collect(Collectors.toList());
        if(opt.isPresent()){
            DashboardTracker tracker = opt.get();
            System.out.println(tracker);
        }
        return idoc;
    }
}
