package com.te.DashboardTracker;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface DashboardTrackerRepository extends JpaRepository<DashboardTracker, String> {
    // You can define query methods as needed, example:
    // List<DashboardTracker> findByIntSenderIdAndIntReceiverId(String senderId, String receiverId);
    Optional<DashboardTracker> findByIdocNumber(String idocNumber);
    Optional<DashboardTracker> findByReferenceNumber(String referenceNumber);
}