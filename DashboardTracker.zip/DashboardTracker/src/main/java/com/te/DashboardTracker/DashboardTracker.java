package com.te.DashboardTracker;


import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "tyco_dashboard_logging")
public class DashboardTracker {
    @Id
    @Column(name = "UNIQUE_NUMBER", length = 50, nullable = false)
    private String uniqueNumber;

    @Column(name = "REFERENCE_NUMBER", length = 20, nullable = false)
    private String referenceNumber;

    @Column(name = "BPID", length = 20)
    private String bpid;

    @Column(name = "DATE_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateTime;

    @Column(name = "PARTNER_NAME", length = 256)
    private String partnerName;

    @Column(name = "PARTNER_NUMBER", length = 20)
    private String partnerNumber;

    @Column(name = "INT_SENDER_ID", length = 35)
    private String intSenderId;

    @Column(name = "INT_RECEIVER_ID", length = 35)
    private String intReceiverId;

    @Column(name = "INT_CONTROL_NO", length = 20)
    private String intControlNo;

    @Column(name = "STATUS", length = 256)
    private String status;

    @Column(name = "BACKUP_FILE_NAME", length = 256)
    private String backupFileName;

    @Column(name = "TRANSACTION_TYPE", length = 30)
    private String transactionType;

    @Column(name = "ALA_CODE", length = 50)
    private String alaCode;

    @Column(name = "IDOC_NUMBER", length = 30)
    private String idocNumber;

    @Column(name = "TRANSACTION_SET", length = 30)
    private String transactionSet;

    // Getters and setters for all fields


    public String getUniqueNumber() {
        return uniqueNumber;
    }

    public void setUniqueNumber(String uniqueNumber) {
        this.uniqueNumber = uniqueNumber;
    }

    public String getReferenceNumber() {
        return referenceNumber;
    }

    public void setReferenceNumber(String referenceNumber) {
        this.referenceNumber = referenceNumber;
    }

    public String getBpid() {
        return bpid;
    }

    public void setBpid(String bpid) {
        this.bpid = bpid;
    }

    public Date getDateTime() {
        return dateTime;
    }

    public void setDateTime(Date dateTime) {
        this.dateTime = dateTime;
    }

    public String getPartnerName() {
        return partnerName;
    }

    public void setPartnerName(String partnerName) {
        this.partnerName = partnerName;
    }

    public String getPartnerNumber() {
        return partnerNumber;
    }

    public void setPartnerNumber(String partnerNumber) {
        this.partnerNumber = partnerNumber;
    }

    public String getIntSenderId() {
        return intSenderId;
    }

    public void setIntSenderId(String intSenderId) {
        this.intSenderId = intSenderId;
    }

    public String getIntReceiverId() {
        return intReceiverId;
    }

    public void setIntReceiverId(String intReceiverId) {
        this.intReceiverId = intReceiverId;
    }

    public String getIntControlNo() {
        return intControlNo;
    }

    public void setIntControlNo(String intControlNo) {
        this.intControlNo = intControlNo;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getBackupFileName() {
        return backupFileName;
    }

    public void setBackupFileName(String backupFileName) {
        this.backupFileName = backupFileName;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public String getAlaCode() {
        return alaCode;
    }

    public void setAlaCode(String alaCode) {
        this.alaCode = alaCode;
    }

    public String getIdocNumber() {
        return idocNumber;
    }

    public void setIdocNumber(String idocNumber) {
        this.idocNumber = idocNumber;
    }

    public String getTransactionSet() {
        return transactionSet;
    }

    public void setTransactionSet(String transactionSet) {
        this.transactionSet = transactionSet;
    }
}
