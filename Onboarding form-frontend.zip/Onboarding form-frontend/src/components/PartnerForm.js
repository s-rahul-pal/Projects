import React from 'react';
import usePartnerForm from './usePartnerForm';
import './PartnerForm.css';
import teLogo from '../assets/TEConnectivity.jpg';

const PartnerForm = () => {
  // const [files, setFiles] = React.useState({});
  const [qaOpen, setQaOpen] = React.useState(false);
  const [prodOpen, setProdOpen] = React.useState(false);
  const [showPreview, setShowPreview] = React.useState(false);
  const [showConfirm, setShowConfirm] = React.useState(false);
  // const specFileInputRefs = React.useRef([]);

  const resetEdiFields = (section = '') => {
    // section: '', 'QA', etc.
    setFormData(prev => ({
      ...prev,
      // Common EDI fields
      [`${section}isaIdQualifier`]: '',
      [`${section}isaId`]: '',
      [`${section}gsId`]: '',
      [`${section}transactionTypes`]: '',
      [`${section}vendorId`]: '',
      [`${section}customerPlantId`]: '',
      
      [`${section}unbIdQualifier`]: '',
      [`${section}unbId`]: '',
      [`${section}vdaId`]: '',
      [`${section}fileFormat`]: '',
      // Sample/spec files (if you store file names/paths in formData)
      [`${section}samplePath`]: '',
      [`${section}specPath`]: '',
      // Remarks
      [`${section}RemarksDescription`]: '',
      [`${section}remarksFile`]: '',
      // Protocols
      [`${section}protocol`]: '',
      [`${section}as2Id`]: '',
      [`${section}endpoint`]: '',
      [`${section}ssl`]: '',
      [`${section}sslCert`]: '',
      [`${section}payloadType`]: '',
      [`${section}encryptionAlgo`]: '',
      [`${section}signingAlgo`]: '',
      [`${section}mdnMode`]: '',
      [`${section}exchangeCert`]: '',
      [`${section}signingCert`]: '',
      [`${section}oftp2Cert`]: '',
      [`${section}ssid`]: '',
      [`${section}sfid`]: '',
      [`${section}oftp2Password`]: '',
      [`${section}host`]: '',
      [`${section}port`]: '',
      [`${section}sftphost`]: '',
      [`${section}username`]: '',
      [`${section}authType`]: '',
      [`${section}sftpPassword`]: '',
      [`${section}directory`]: '',
      [`${section}otherProtocolDescription`]: '',
      [`${section}connectivityDetails`]: '',
      // Add any other EDI/protocol-related fields you use in your form
    }));
  };
  const resetProtocolFields = (section = '') => {
    setFormData(prev => ({
      ...prev,
      [`${section}protocol`]: '',
      [`${section}as2Id`]: '',
      [`${section}endpoint`]: '',
      [`${section}ssl`]: '',
      [`${section}sslCert`]: '',
      [`${section}payloadType`]: '',
      [`${section}encryptionAlgo`]: '',
      [`${section}signingAlgo`]: '',
      [`${section}mdnMode`]: '',
      [`${section}exchangeCert`]: '',
      [`${section}signingCert`]: '',
      [`${section}oftp2Cert`]: '',
      [`${section}ssid`]: '',
      [`${section}sfid`]: '',
      [`${section}oftp2Password`]: '',
      [`${section}host`]: '',
      [`${section}port`]: '',
      [`${section}sftphost`]: '',
      [`${section}username`]: '',
      [`${section}authType`]: '',
      [`${section}sftpPassword`]: '',
      [`${section}directory`]: '',
      [`${section}otherProtocolDescription`]: '',
      [`${section}connectivityDetails`]: '',
    }));
  };
  // const { hasSpecFiles } = usePartnerForm();
  const {
    formData,
    setFormData,
    specFileInputs,
    specFiles,
    qaSpecFileInputs,
    qaSpecFiles,
    specWarning,
    highlightSpecRow,
    setHighlightSpecRow,
    setSpecWarning,
    envSame,
    setEnvSame,
    envTab,
    setEnvTab,
    protocol,
    ssl,
    authType,
    sampleWarning,
    sampleFileInputs,
    sampleFiles,
    highlightSampleRow,
    setHighlightSampleRow,
    setSampleWarning,
    qaSampleFileInputs,
    qaSampleFiles,
    qaSampleWarning,
    setQASampleWarning,
    highlightQASpecRow,
    setHighlightQASpecRow,
    highlightQASampleRow,
    setHighlightQASampleRow,
    qaSpecWarning,
    setQASpecWarning,
    handleAddQaSpecFileInput,
    handleRemoveQaSpecFileInput,
    handleQaSpecFileChange,
    handleAddQASampleFileInput,
    handleRemoveQASampleFileInput,
    handleQASampleFileChange,
    handleAddSpecFileInput,
    handleSpecFileChange,
    handleRemoveSpecFileInput,
    handleInputChange,
    handleFileChange,
    handleSubmit,
    handleAddSampleFileInput,
    handleRemoveSampleFileInput,
    handleSampleFileChange,
    getFileNameOrValue,
    renderFileList,

  } = usePartnerForm();

  // Place the useEffect here, after state and before return
  React.useEffect(() => {
    if (envSame === "No") {
      setQaOpen(false);
      setProdOpen(false);
    } else if (envSame === "Yes") {
      setQaOpen(true);
      setProdOpen(true);
    }
  }, [envSame]);

  const handleFormSubmit = (e) => {
    e.preventDefault();
    if (envSame === 'No') {
      if (!qaOpen) {
        alert('Please fill QA/UAT/Non-Production Configurations before submitting.');
        setQaOpen(true);
        return;
      }
      if (!prodOpen) {
        alert('Please fill Production Configurations before submitting.');
        setProdOpen(true);
        return;
      }
    }
    setShowPreview(true);
  };

  // Actually submit the form after confirmation
  const handleFinalSubmit = async () => {

    setShowPreview(true);
  };

  // Helper to render a field in preview
  const showValue = (value) => {
    if (value instanceof File) return value.name;
    if (value === undefined || value === null || value === '') return <span style={{ color: '#aaa' }}>NA</span>;
    return value;
  };
  //   const renderPreviewField = (label, value) => (
  //     <div style={{ marginBottom: 16 }}>
  //   {Object.entries(formData).map(([key, value]) => (
  //     <div key={key} style={{ marginBottom: 8 }}>
  //       <strong>{prettifyLabel(key)}:</strong>{' '}
  //       {value instanceof File
  //         ? value.name
  //         : value && value !== ''
  //           ? value.toString()
  //           : <span style={{ color: '#aaa' }}>NA</span>
  //       }
  //     </div>
  //   ))}
  // </div>
  //   );

  //  const handleFormSubmit = (e) => {
  //   console.log('envSame:', envSame, 'qaOpen:', qaOpen, 'prodOpen:', prodOpen);
  //   if (envSame === 'No') {
  //     if (!qaOpen) {
  //       e.preventDefault();
  //       alert('Please fill QA/UAT/Non-Production Configurations before submitting.');
  //       setQaOpen(true);
  //       return;
  //     }
  //     if (!prodOpen) {
  //       e.preventDefault();
  //       alert('Please fill Production Configurations before submitting.');
  //       setProdOpen(true);
  //       return;
  //     }
  //   }
  //   // If both are open or envSame is Yes, allow submit
  //   // The hook's handleSubmit will call e.preventDefault() again, but that's fine
  //   handleSubmit(e);
  // };
  return (
    <div className="partner-form-container">
      <img src={teLogo} id="logo" alt="TE Connectivity" />
      <h2>EDI PARTNER ONBOARDING FORM</h2>
      
      {!showPreview && (
        <form onSubmit={handleFinalSubmit} className="partner-form">

          <div className="form-section">

<p className="mandatory-remark">
            <b>Note:</b> <span> Fields marked with <span style={{ color: 'red' }}>*</span> are mandatory to fill. 
            <br/>For any queries or support, please contact <span style={{ color: 'blue' }}>b2bedisupport@te.com</span></span>.
            
            {/* 3. Please check all the details before submitting the form. */}
          </p>

            <h4 className="section-title">Partner Information</h4>

            <label>Partner Name<span style={{ color: 'red' }}>*</span></label>
            <input type="text" name="partnerName" value={formData.partnerName} onChange={handleInputChange} required />

            <label>Sold To<span style={{ color: 'red' }}>*</span></label>
            <input type="text" name="soldTo" value={formData.soldTo} onChange={handleInputChange} required />

            <label>Ship To</label>
            <input type="text" name="shipTo" value={formData.shipTo} onChange={handleInputChange}  />
          </div>
          <div className="form-section">
            <h4 className="section-title">Contact Details [Email]</h4>

            <label>Technical Contact<span style={{ color: 'red' }}>*</span></label>
            <input type="email" name="technicalContactDetails" value={formData.technicalContactDetails} onChange={handleInputChange} required />

            <label>Business Contact<span style={{ color: 'red' }}>*</span></label>
            <input type="email" name="businessContactDetails" value={formData.businessContactDetails} onChange={handleInputChange} required />

            <label>TE Counterpart Contact<span style={{ color: 'red' }}>*</span></label>
            <input type="email" name="teCounterpartContactDetails" value={formData.teCounterpartContactDetails} onChange={handleInputChange} required />

          </div>

          <div className="form-section">
            <h4 className="section-title">Technical Configurations</h4>
            <label>Are the configurations for both QA and Production environment same?<span style={{ color: 'red' }}>*</span></label>
            <select
              name="envSame"
              value={formData.envSame}
              onChange={handleInputChange}
              // onChange={e => setEnvSame(e.target.value)}
              required
            >
              <option value="">--Select--</option>
              <option value="Yes">Yes</option>
              <option value="No">No</option>
            </select>

            {formData.envSame === 'Yes' && (
              <>
                <div className="form-section">
                  <div className="form-section">

                    <label>EDI Standard<span style={{ color: 'red' }}>*</span></label>
                    <div className="chip-group">
                      {["ANSI X12", "EDIFACT", "VDA", "Others"].map(option => (
                        <label
                          key={option}
                          className={`chip ${formData.ediStandard === option ? "selected" : ""}`}
                        >
                          
                          <input
                            type="radio"
                            name="ediStandard"
                            value={option}
                            checked={formData.ediStandard === option}
                            onChange={e => {
                              resetEdiFields('');
                              setFormData(prev => ({
                                ...prev,
                                ediStandard: e.target.value,
                                specification: e.target.value
                              }));
                            }}
                            required
                          />
                          {option}
                        </label>
                      ))}
                    </div>
                  </div>

                  {formData.ediStandard === 'ANSI X12' && (
                    <>

                      <label>ISA ID Qualifier<span style={{ color: 'red' }}>*</span></label>
                      <input type="text" name='isaIdQualifier' value={formData.isaIdQualifier} onChange={handleInputChange} required />

                      <label>ISA ID<span style={{ color: 'red' }}>*</span></label>
                      <input type="text" name='isaId' value={formData.isaId} onChange={handleInputChange} required />

                      <label>GS ID<span style={{ color: 'red' }}>*</span></label>
                      <input type="text" name='gsId' value={formData.gsId} onChange={handleInputChange} required />

                      <label>Transaction Types<span style={{ color: 'red' }}>*</span></label>
                      <input type="text" name='transactionTypes' value={formData.transactionTypes} onChange={handleInputChange} required />

                      <label>Transaction Version</label>
                      <input type="text" name='transactionVersion' value={formData.transactionVersion} onChange={handleInputChange}  />

                      <label>Supplier/Vendor ID<span style={{ color: 'red' }}>*</span></label>
                      <input type="text" name='vendorId' value={formData.vendorId} onChange={handleInputChange} required />

                      <label>Plant ID<span style={{ color: 'red' }}>*</span></label>
                      <input type="text" name='customerPlantId' value={formData.customerPlantId} onChange={handleInputChange} required />

                    </>
                  )}

                  {formData.ediStandard === 'EDIFACT' && (
                    <>

                      <label>UNB ID Qualifier<span style={{ color: 'red' }}>*</span></label>
                      <input type="text" name='unbIdQualifier' value={formData.unbIdQualifier} onChange={handleInputChange} required />

                      <label>UNB ID<span style={{ color: 'red' }}>*</span></label>
                      <input type="text" name='unbId' value={formData.unbId} onChange={handleInputChange} required />

                      <label>Transaction Types<span style={{ color: 'red' }}>*</span></label>
                      <input type="text" name='transactionTypes' value={formData.transactionTypes} onChange={handleInputChange} required />

<label>Transaction Version</label>
                      <input type="text" name='transactionVersion' value={formData.transactionVersion} onChange={handleInputChange}  />

                      <label>Supplier/Vendor ID<span style={{ color: 'red' }}>*</span></label>
                      <input type="text" name='vendorId' value={formData.vendorId} onChange={handleInputChange} required />

                      <label>Plant ID<span style={{ color: 'red' }}>*</span><span style={{ color: 'red' }}>*</span></label>
                      <input type="text" name='customerPlantId' value={formData.customerPlantId} onChange={handleInputChange} required />

                    </>
                  )}

                  {formData.ediStandard === 'VDA' && (
                    <>

                      <label>VDA ID<span style={{ color: 'red' }}>*</span></label>
                      <input type="text" name='vdaId' value={formData.vdaId} onChange={handleInputChange} />

                      <label>Transaction Types<span style={{ color: 'red' }}>*</span></label>
                      <input type="text" name='transactionTypes' value={formData.transactionTypes} onChange={handleInputChange} required />

<label>Transaction Version</label>
                      <input type="text" name='transactionVersion' value={formData.transactionVersion} onChange={handleInputChange}  />

                      <label>Supplier/Vendor ID<span style={{ color: 'red' }}>*</span></label>
                      <input type="text" name='vendorId' value={formData.vendorId} onChange={handleInputChange} required />

                      <label>Plant ID<span style={{ color: 'red' }}>*</span></label>
                      <input type="text" name='customerPlantId' value={formData.customerPlantId} onChange={handleInputChange} required />

                    </>
                  )}

                  {formData.ediStandard === 'Others' && (
                    <>
                      <label>File Format [XML/CSV/FlatFile]<span style={{ color: 'red' }}>*</span></label>
                      <input type="text" name='fileFormat' value={formData.fileFormat} onChange={handleInputChange} required />


                    </>
                  )}
                </div>

                <label>Upload Sample File</label>
                {sampleFileInputs.map((id, index) => (
                  <div
                    key={id}
                    className={`spec-upload-row${highlightSampleRow && index === sampleFileInputs.length - 1 && !sampleFiles[index] ? ' spec-upload-row-error' : ''}`}
                    style={{ display: 'flex', alignItems: 'center', gap: '8px' }}
                  >
                    {/* Only show file input if no file is selected */}
                    {/* {!sampleFiles[index] ? (
                      <input
                        type="file"
                        name="samplePath"
                        onChange={e => handleSampleFileChange(e, index)}
                        style={{ flex: 1 }}
                      />
                    ) : (
                      <span style={{ marginLeft: 8, color: '#333', fontStyle: 'italic' }}>
                        {sampleFiles[index].name || (typeof sampleFiles[index] === 'string' ? sampleFiles[index] : '')}
                      </span>
                    )} */}

                      <input
                        type="file"
                        name="samplePath"
                        onChange={e => handleSampleFileChange(e, index)}
                        style={{ flex: 1 }}
                      />
                    {/* Show delete button only if more than one row */}
                    {sampleFileInputs.length > 1 && (
                      <button
                        type="button"
                        className="icon-btn delete-btn"
                        title="Delete file"
                        onClick={() => handleRemoveSampleFileInput(index)}
                        style={{ marginLeft: 4 }}
                      >
                        <span role="img" aria-label="delete">&#128465;</span>
                      </button>
                    )}
                    {/* Add Button */}
                    <button
                      type="button"
                      className="icon-btn add-btn"
                      title="Add new file"
                      onClick={() => {
                        if (!sampleFiles[index]) {
                          setHighlightSampleRow(true);
                          setSampleWarning('Please upload a file before adding a new entry.');
                          setTimeout(() => {
                            setHighlightSampleRow(false);
                            setSampleWarning('');
                          }, 2000); // Hide warning after 3 seconds
                        } else {
                          setHighlightSampleRow(false);
                          setSampleWarning('');
                          handleAddSampleFileInput();
                        }
                      }}
                      style={{ marginLeft: 4 }}
                    >
                      <span style={{ fontWeight: 'bold', fontSize: '1.2em' }}>+</span>
                    </button>
                  </div>
                ))}

                {sampleWarning && (
                  <div className="sample-warning">
                    {sampleWarning}
                  </div>
                )}

                <label>Specification Files</label>
                {specFileInputs.map((id, index) => (
                  <div
                    key={id}
                    className={`spec-upload-row${highlightSpecRow && index === specFileInputs.length - 1 && !specFiles[index] ? ' spec-upload-row-error' : ''}`}
                    style={{ display: 'flex', alignItems: 'center', gap: '8px' }}
                  >
                    {/* Only show file input if no file is selected */}
                    {/* {!specFiles[index] ? (
                      <input
                        type="file"
                        name="specPath"
                        onChange={e => handleSpecFileChange(e, index)}
                        style={{ flex: 1 }}
                      />
                    ) : (
                      <>
                        <span style={{ marginLeft: 8, color: '#333', fontStyle: 'italic' }}>
                          {specFiles[index].name || (typeof specFiles[index] === 'string' ? specFiles[index] : '')}
                        </span>

                      </>
                    )} */}
                      <input
                        type="file"
                        name="specPath"
                        onChange={e => handleSpecFileChange(e, index)}
                        style={{ flex: 1 }}
                      />

                    {/* Show delete button only if more than one row */}
                    {specFileInputs.length > 1 && (
                      <button
                        type="button"
                        className="icon-btn delete-btn"
                        title="Delete this row"
                        onClick={() => handleRemoveSpecFileInput(index)}
                        style={{ marginLeft: 4 }}
                      >
                        <span role="img" aria-label="delete">&#128465;</span>
                      </button>
                    )}
                    {/* Add Button */}
                    <button
                      type="button"
                      className="icon-btn add-btn"
                      title="Add new specification row"
                      onClick={() => {
                        if (!specFiles[index]) {
                          setHighlightSpecRow(true);
                          setSpecWarning('Please upload a file before adding a new row.');
                          setTimeout(() => {
                            setHighlightSpecRow(false);
                            setSpecWarning('');
                          }, 2000);
                        } else {
                          setHighlightSpecRow(false);
                          setSpecWarning('');
                          handleAddSpecFileInput();
                        }
                      }}
                      style={{ marginLeft: 4 }}
                    >
                      <span style={{ fontWeight: 'bold', fontSize: '1.2em' }}>+</span>
                    </button>
                  </div>
                ))}

                {specWarning && (
                  <div className="spec-warning">
                    {specWarning}
                  </div>
                )}

                {/* <div className="form-section">
                <label className='remark-section-title'>Remarks/Any special guidelines</label>
                <div className="remarks-subsection">
                <label>Description</label>
                <input type="text" name="remarksDescription" value={formData.remarksDescription} onChange={handleInputChange} />

                <div className="cert-upload-row">
                  <label htmlFor="remarksFile">Upload file:</label>
                  <input type="file" id="remarksFile" name="remarksFile" onChange={handleFileChange} />
                </div>
                </div>
              </div> */}
                <div className="form-section remarks-section">
                  <label className="remark-section-title">Remarks/Any special guidelines</label>
                  <div className="remarks-subsection">
                    <div>
                      <label htmlFor="remarksDescription">Description</label>
                      <input
                        type="text"
                        id="remarksDescription"
                        name="remarksDescription"
                        value={formData.remarksDescription}
                        onChange={handleInputChange}
                      />
                    </div>
                    <div className="cert-upload-row">
                      <label htmlFor="remarksFile">Upload file</label>
                      <input
                        type="file"
                        id="remarksFile"
                        name="remarksFile"
                        onChange={handleFileChange}
                      />
                    </div>
                  </div>
                </div>

                <label>Communication Protocol<span style={{ color: 'red' }}>*</span></label>
                <select name="protocol" value={protocol} onChange={e => {
                  resetProtocolFields('');
                  handleInputChange(e);
                }} required>
                  <option value="">--Select--</option>
                  <option value="AS2">AS2</option>
                  <option value="SFTP">SFTP</option>
                  <option value="OFTP2">OFTP2</option>
                  <option value="Others">Others</option>
                </select>

                {protocol === 'AS2' && (
                  <div className="form-section">
                    <label>AS2 ID<span style={{ color: 'red' }}>*</span></label>
                    <input type="text" name="as2Id" value={formData.as2Id} onChange={handleInputChange} required />

                    <label>Endpoint<span style={{ color: 'red' }}>*</span></label>
                    <input type="text" name="endpoint" value={formData.endpoint} onChange={handleInputChange} required />

                    <label>SSL<span style={{ color: 'red' }}>*</span></label>
                    <select name="ssl" value={ssl} onChange={handleInputChange} required>
                      <option value="">--Select--</option>
                      <option value="Yes">Yes</option>
                      <option value="No">No</option>
                    </select>

                    {ssl === 'Yes' && (
                      <>
                        <div className="cert-upload-row">
                          <label htmlFor="sslCert">SSL/CA Certificate</label>
                          <input type="file" id="sslCert" name="sslCert" onChange={handleFileChange} required />
                        </div>
                      </>
                    )}

                    <label>Payload Type<span style={{ color: 'red' }}>*</span></label>
                    <input type="text" name="payloadType" value={formData.payloadType} onChange={handleInputChange} required />

                    <label>Encryption Algorithm<span style={{ color: 'red' }}>*</span></label>
                    <input type="text" name="encryptionAlgo" value={formData.encryptionAlgo} onChange={handleInputChange} required />

                    <label>Signing Algorithm<span style={{ color: 'red' }}>*</span></label>
                    <input type="text" name="signingAlgo" value={formData.signingAlgo} onChange={handleInputChange} required />

                    <label>MDN Mode<span style={{ color: 'red' }}>*</span></label>
                    <select name="mdnMode" value={formData.mdnMode} onChange={handleInputChange} required>
                      <option value="">--Select--</option>
                      <option value="Synchronous">Synchronous</option>
                      <option value="Asynchronous">Asynchronous</option>
                    </select>

                    <div className="cert-upload-row">
                      <label htmlFor="exchangeCert">Exchange Certificate<span style={{ color: 'red' }}>*</span></label>
                      <input type="file" id="exchangeCert" name="exchangeCert" onChange={handleFileChange} required />
                    </div>
                    <div className="cert-upload-row">
                      <label htmlFor="signingCert">Signing Certificate<span style={{ color: 'red' }}>*</span></label>
                      <input type="file" id="signingCert" name="signingCert" onChange={handleFileChange} required />
                    </div>
                  </div>
                )}

                {protocol === 'OFTP2' && (
                  <div className="form-section">
                    <label>SSID<span style={{ color: 'red' }}>*</span></label>
                    <input type="text" name="ssid" value={formData.ssid} onChange={handleInputChange} required />
                    <label>SFID<span style={{ color: 'red' }}>*</span></label>
                    <input type="text" name="sfid" value={formData.sfid} onChange={handleInputChange} required />
                    <label>Password<span style={{ color: 'red' }}>*</span></label>
                    <input type="password" name="oftp2Password" value={formData.oftp2Password} onChange={handleInputChange} required />
                    <label>Host<span style={{ color: 'red' }}>*</span></label>
                    <input type="text" name="host" value={formData.host} onChange={handleInputChange} required />
                    <label>Port<span style={{ color: 'red' }}>*</span></label>
                    <input type="text" name="port" value={formData.port} onChange={handleInputChange} required />
                    <div className="cert-upload-row">
                      <label htmlFor="oftp2Cert">Certificate<span style={{ color: 'red' }}>*</span></label>
                      <input type="file" id="oftp2Cert" name="oftp2Cert" onChange={handleFileChange} required />
                    </div>
                  </div>
                )}

                {protocol === 'SFTP' && (
                  <div className="form-section">
                    <label>Host<span style={{ color: 'red' }}>*</span></label>
                    <input type="text" name="sftphost" value={formData.sftphost} onChange={handleInputChange} required />
                    <label>Port<span style={{ color: 'red' }}>*</span></label>
                    <input type="text" name="port" value={formData.port} onChange={handleInputChange} required />
                    <label>Username<span style={{ color: 'red' }}>*</span></label>
                    <input type="text" name="username" value={formData.username} onChange={handleInputChange} required />

                    <label>Authentication Type<span style={{ color: 'red' }}>*</span></label>
                    <select name="authType" value={authType} onChange={handleInputChange} required>
                      <option value="">--Select--</option>
                      <option value="Password">Password</option>
                      <option value="Key">Key</option>
                    </select>

                    {authType === 'Password' && (
                      <>
                        <label>Password<span style={{ color: 'red' }}>*</span></label>
                        <input type="password" name="sftpPassword" value={formData.sftpPassword} onChange={handleInputChange} required />
                      </>
                    )}

                    <label>Directory<span style={{ color: 'red' }}>*</span></label>
                    <input type="text" name="directory" value={formData.directory} onChange={handleInputChange} required />
                  </div>
                )}

                {protocol === 'Others' && (
                  <div className="form-section">
                    <label>Description<span style={{ color: 'red' }}>*</span></label>
                    <input type="text" name="otherProtocolDescription" value={formData.otherProtocolDescription} onChange={handleInputChange} required />

                    <div className="cert-upload-row">
                      <label htmlFor="connectivityDetails">Connectivity Parameters Details<span style={{ color: 'red' }}>*</span></label>
                      <input type="file" id="connectivityDetails" name="connectivityDetails" onChange={handleFileChange} required />
                    </div>
                  </div>
                )}
              </>
            )}

            {formData.envSame === 'No' && (
              <>
                <div className="form-section ">
                  <h4
                    className="configuration-section-title"
                    style={{ cursor: 'pointer', display: 'flex', alignItems: 'center', userSelect: 'none' }}
                    onClick={() => setQaOpen(open => !open)}
                  >
                    <span style={{
                      display: 'inline-block',
                      transition: 'transform 0.2s',
                      transform: qaOpen ? 'rotate(90deg)' : 'rotate(0deg)',
                      marginRight: 8,
                      fontSize: '1.2em'
                    }}>▶</span>
                    QA/UAT/Non-Production Configurations
                  </h4>
                  {qaOpen && (
                    <>
                      <div className="form-section">
                        <label>EDI Standard<span style={{ color: 'red' }}>*</span></label>
                        <div className="chip-group">
                          {["ANSI X12", "EDIFACT", "VDA", "Others"].map(option => (
                            <label
                              key={option}
                              className={`chip ${formData.QAediStandard === option ? "selected" : ""}`}
                            >

                              <input
                                type="radio"
                                name="QAediStandard"
                                value={option}
                                checked={formData.QAediStandard === option}
                                onChange={e => {
                                  resetEdiFields('QA');
                                  setFormData(prev => ({
                                    ...prev,
                                    QAediStandard: e.target.value,
                                    QAspecification: e.target.value
                                  }));
                                }}
                                required
                              />
                              {option}
                            </label>
                          ))}
                        </div>


                        {formData.QAediStandard === 'ANSI X12' && (
                          <>

                            <label>ISA ID Qualifier<span style={{ color: 'red' }}>*</span></label>
                            <input type="text" name='QAisaIdQualifier' value={formData.QAisaIdQualifier} onChange={handleInputChange} required />

                            <label>EDI ID<span style={{ color: 'red' }}>*</span></label>
                            <input type="text" name='QAisaId' value={formData.QAisaId || ''} onChange={handleInputChange} required />

                            <label>GS ID<span style={{ color: 'red' }}>*</span></label>
                            <input type="text" name='QAgsId' value={formData.QAgsId || ''} onChange={handleInputChange} required />

                            <label>Transaction Types<span style={{ color: 'red' }}>*</span></label>
                            <input type="text" name='QAtransactionTypes' value={formData.QAtransactionTypes || ''} onChange={handleInputChange} required />

<label>Transaction Version</label>
                      <input type="text" name='QATransactionVersion' value={formData.QATransactionVersion} onChange={handleInputChange}  />

                            <label>Supplier/Vendor ID<span style={{ color: 'red' }}>*</span></label>
                            <input type="text" name='QAvendorId' value={formData.QAvendorId || ''} onChange={handleInputChange} required />

                            <label>Plant ID<span style={{ color: 'red' }}>*</span></label>
                            <input type="text" name='QACustomerPlantId' value={formData.QACustomerPlantId || ''} onChange={handleInputChange} required />
                          </>
                        )}

                        {formData.QAediStandard === 'EDIFACT' && (
                          <>

                            <label>UNB ID Qualifier<span style={{ color: 'red' }}>*</span></label>
                            <input type="text" name='QAunbIdQualifier' value={formData.QAunbIdQualifier || ''} onChange={handleInputChange} required />

                            <label>UNB ID<span style={{ color: 'red' }}>*</span></label>
                            <input type="text" name='QAunbId' value={formData.QAunbId || ''} onChange={handleInputChange} required />
                            <label>Transaction Types<span style={{ color: 'red' }}>*</span></label>
                            <input type="text" name='QAtransactionTypes' value={formData.QAtransactionTypes || ''} onChange={handleInputChange} required />
<label>Transaction Version</label>
                      <input type="text" name='QATransactionVersion' value={formData.QATransactionVersion} onChange={handleInputChange}  />

                            <label>Supplier/Vendor ID<span style={{ color: 'red' }}>*</span></label>
                            <input type="text" name='QAvendorId' value={formData.QAvendorId || ''} onChange={handleInputChange} required />

                            <label>Plant ID<span style={{ color: 'red' }}>*</span></label>
                            <input type="text" name='QACustomerPlantId' value={formData.QACustomerPlantId || ''} onChange={handleInputChange} required />

                          </>
                        )}

                        {formData.QAediStandard === 'VDA' && (
                          <>

                            <label>VDA ID<span style={{ color: 'red' }}>*</span></label>
                            <input type="text" name='QAvdaId' value={formData.QAvdaId || ''} onChange={handleInputChange} />

                            <label>Transaction Types<span style={{ color: 'red' }}>*</span></label>
                            <input type="text" name='QAtransactionTypes' value={formData.QAtransactionTypes || ''} onChange={handleInputChange} required />
<label>Transaction Version</label>
                      <input type="text" name='QATransactionVersion' value={formData.QATransactionVersion} onChange={handleInputChange}  />

                            <label>Supplier/Vendor ID<span style={{ color: 'red' }}>*</span></label>
                            <input type="text" name='QAvendorId' value={formData.QAvendorId || ''} onChange={handleInputChange} required />

                            <label>Plant ID<span style={{ color: 'red' }}>*</span></label>
                            <input type="text" name='QACustomerPlantId' value={formData.QACustomerPlantId || ''} onChange={handleInputChange} required />

                          </>
                        )}

                        {formData.QAediStandard === 'Others' && (
                          <>
                            <label>File Format [XML/CSV/FlatFile]<span style={{ color: 'red' }}>*</span></label>
                            <input type="text" name='QAfileFormat' value={formData.QAfileFormat || ''} onChange={handleInputChange} required />

                          </>
                        )}
                      </div>

                      {/* // ...inside the QA/UAT/Non-Production Configurations section... */}
                      <label>Upload Sample File</label>
                      {qaSampleFileInputs.map((id, index) => (
                        <div
                          key={id}
                          className={`spec-upload-row${highlightQASampleRow && index === qaSampleFileInputs.length - 1 && !qaSampleFiles[index] ? ' spec-upload-row-error' : ''}`}
                          style={{ display: 'flex', alignItems: 'center', gap: '8px' }}
                        >
                          {/* Only show file input if no file is selected */}
                          {/* {!qaSampleFiles[index] ? (
                            <input
                              type="file"
                              name="QAsamplePath"
                              onChange={e => handleQASampleFileChange(e, index)}
                              style={{ flex: 1 }}
                            />
                          ) : (
                            <span style={{ marginLeft: 8, color: '#333', fontStyle: 'italic' }}>
                              {qaSampleFiles[index].name || (typeof qaSampleFiles[index] === 'string' ? qaSampleFiles[index] : '')}
                            </span>
                          )} */}
                          <input
                              type="file"
                              name="QAsamplePath"
                              onChange={e => handleQASampleFileChange(e, index)}
                              style={{ flex: 1 }}
                            />

                          {/* Show delete button only if more than one row */}
                          {qaSampleFileInputs.length > 1 && (
                            <button
                              type="button"
                              className="icon-btn delete-btn"
                              title="Delete file"
                              onClick={() => handleRemoveQASampleFileInput(index)}
                              style={{ marginLeft: 4 }}
                            >
                              <span role="img" aria-label="delete">&#128465;</span>
                            </button>
                          )}
                          {/* Add Button */}
                          <button
                            type="button"
                            className="icon-btn add-btn"
                            title="Add new file"
                            onClick={() => {
                              if (!qaSampleFiles[index]) {
                                setHighlightQASampleRow(true);
                                setQASampleWarning('Please upload a file before adding a new entry.');
                                setTimeout(() => {
                                  setHighlightQASampleRow(false);
                                  setQASampleWarning('');
                                }, 2000); // Hide warning after 2 seconds
                              } else {
                                setHighlightQASampleRow(false);
                                setQASampleWarning('');
                                handleAddQASampleFileInput();
                              }
                            }}
                            style={{ marginLeft: 4 }}
                          >
                            <span style={{ fontWeight: 'bold', fontSize: '1.2em' }}>+</span>
                          </button>
                        </div>
                      ))}
                      {qaSampleWarning && (
                        <div className="sample-warning">
                          {qaSampleWarning}
                        </div>
                      )}
                      {qaSampleWarning && (
                        <div className="sample-warning">
                          {qaSampleWarning}
                        </div>
                      )}


                      <label>Specification Files</label>
                      {qaSpecFileInputs.map((id, index) => (
                        <div
                          key={id}
                          className={`spec-upload-row${highlightQASpecRow && index === qaSpecFileInputs.length - 1 && !qaSpecFiles[index] ? ' spec-upload-row-error' : ''}`}
                          style={{ display: 'flex', alignItems: 'center', gap: '8px' }}
                        >
                          {/* Only show file input if no file is selected */}
                          {/* {!qaSpecFiles[index] ? (
                            <input
                              type="file"
                              name="QAspecPath"
                              onChange={e => handleQaSpecFileChange(e, index)}
                              style={{ flex: 1 }}
                            />
                          ) : (
                            <span style={{ marginLeft: 8, color: '#333', fontStyle: 'italic' }}>
                              {qaSpecFiles[index].name || (typeof qaSpecFiles[index] === 'string' ? qaSpecFiles[index] : '')}
                            </span>
                          )} */}

                            <input
                              type="file"
                              name="QAspecPath"
                              onChange={e => handleQaSpecFileChange(e, index)}
                              style={{ flex: 1 }}
                            />
                          {/* Show delete button only if more than one row */}
                          {qaSpecFileInputs.length > 1 && (
                            <button
                              type="button"
                              className="icon-btn delete-btn"
                              title="Delete this row"
                              onClick={() => handleRemoveQaSpecFileInput(index)}
                              style={{ marginLeft: 4 }}
                            >
                              <span role="img" aria-label="delete">&#128465;</span>
                            </button>
                          )}
                          {/* Add Button */}
                          <button
                            type="button"
                            className="icon-btn add-btn"
                            title="Add new specification row"
                            onClick={() => {
                              if (!qaSpecFiles[index]) {
                                setHighlightQASpecRow(true);
                                setQASpecWarning('Please upload a file before adding a new row.');
                                setTimeout(() => {
                                  setHighlightQASpecRow(false);
                                  setQASpecWarning('');
                                }, 2000);
                              } else {
                                setHighlightQASpecRow(false);
                                setQASpecWarning('');
                                handleAddQaSpecFileInput();
                              }
                            }}
                            style={{ marginLeft: 4 }}
                          >
                            <span style={{ fontWeight: 'bold', fontSize: '1.2em' }}>+</span>
                          </button>
                        </div>
                      ))}
                      {qaSpecWarning && (
                        <div className="spec-warning">
                          {qaSpecWarning}
                        </div>
                      )}

                      {qaSpecWarning && (
                        <div className="spec-warning">
                          {qaSpecWarning}
                        </div>
                      )}


                      <div className="form-section remarks-section">
                        <label className="remark-section-title">Remarks/Any special guidelines</label>
                        <div className="remarks-subsection">
                          <div>
                            <label htmlFor="QARemarksDescription">Description</label>
                            <input
                              type="text"
                              id="QARemarksDescription"
                              name="QARemarksDescription"
                              value={formData.QARemarksDescription}
                              onChange={handleInputChange}
                            />
                          </div>
                          <div className="cert-upload-row">
                            <label htmlFor="QARemarksFile">Upload file</label>
                            <input
                              type="file"
                              id="QARemarksFile"
                              name="QARemarksFile"
                              onChange={handleFileChange}
                            />
                          </div>
                        </div>
                      </div>

                      <label>Communication Protocol<span style={{ color: 'red' }}>*</span></label>
                      <select name="QAprotocol" value={formData.QAprotocol || ''} onChange={e => {
                        resetProtocolFields('QA');
                        handleInputChange(e);
                      }} required>
                        <option value="">--Select--</option>
                        <option value="AS2">AS2</option>
                        <option value="SFTP">SFTP</option>
                        <option value="OFTP2">OFTP2</option>
                        <option value="Others">Others</option>
                      </select>

                      {formData.QAprotocol === 'AS2' && (
                        <div className="form-section">
                          <label>AS2 ID<span style={{ color: 'red' }}>*</span></label>
                          <input type="text" name="QAas2Id" value={formData.QAas2Id || ''} onChange={handleInputChange} required />

                          <label>Endpoint<span style={{ color: 'red' }}>*</span></label>
                          <input type="text" name="QAendpoint" value={formData.QAendpoint || ''} onChange={handleInputChange} required />

                          <label>SSL<span style={{ color: 'red' }}>*</span></label>
                          <select name="QAssl" value={formData.QAssl || ''} onChange={handleInputChange} required>
                            <option value="">--Select--</option>
                            <option value="Yes">Yes</option>
                            <option value="No">No</option>
                          </select>

                          {formData.QAssl === 'Yes' && (
                            <>
                              <div className="cert-upload-row">
                                <label htmlFor="QAsslCert">Certificate<span style={{ color: 'red' }}>*</span></label>
                                <input type="file" id="QAsslCert" name="QAsslCert" onChange={handleFileChange} required />
                              </div>
                            </>
                          )}

                          <label>Payload Type<span style={{ color: 'red' }}>*</span></label>
                          <input type="text" name="QApayloadType" value={formData.QApayloadType || ''} onChange={handleInputChange} required />

                          <label>Encryption Algorithm<span style={{ color: 'red' }}>*</span></label>
                          <input type="text" name="QAencryptionAlgo" value={formData.QAencryptionAlgo || ''} onChange={handleInputChange} required />

                          <label>Signing Algorithm<span style={{ color: 'red' }}>*</span></label>
                          <input type="text" name="QAsigningAlgo" value={formData.QAsigningAlgo || ''} onChange={handleInputChange} required />

                          <label>MDN Mode<span style={{ color: 'red' }}>*</span></label>
                          <select name="QAmdnMode" value={formData.QAmdnMode || ''} onChange={handleInputChange} required>
                            <option value="">--Select--</option>
                            <option value="Synchronous">Synchronous</option>
                            <option value="Asynchronous">Asynchronous</option>
                          </select>

                          <div className="cert-upload-row">
                            <label htmlFor="QAexchangeCert">Exchange Certificate<span style={{ color: 'red' }}>*</span></label>
                            <input type="file" id="QAexchangeCert" name="QAexchangeCert" onChange={handleFileChange} required />
                          </div>
                          <div className="cert-upload-row">
                            <label htmlFor="QAsigningCert">Signing Certificate<span style={{ color: 'red' }}>*</span></label>
                            <input type="file" id="QAsigningCert" name="QAsigningCert" onChange={handleFileChange} required />
                          </div>
                        </div>
                      )}

                      {formData.QAprotocol === 'OFTP2' && (
                        <div className="form-section">
                          <label>SSID<span style={{ color: 'red' }}>*</span></label>
                          <input type="text" name="QAssid" value={formData.QAssid || ''} onChange={handleInputChange} required />
                          <label>SFID<span style={{ color: 'red' }}>*</span></label>
                          <input type="text" name="QAsfid" value={formData.QAsfid || ''} onChange={handleInputChange} required />
                          <label>Password<span style={{ color: 'red' }}>*</span></label>
                          <input type="password" name="QAoftp2Password" value={formData.QAoftp2Password || ''} onChange={handleInputChange} required />
                          <label>Host<span style={{ color: 'red' }}>*</span></label>
                          <input type="text" name="QAhost" value={formData.QAhost || ''} onChange={handleInputChange} required />
                          <label>Port<span style={{ color: 'red' }}>*</span></label>
                          <input type="text" name="QAport" value={formData.QAport || ''} onChange={handleInputChange} required />
                          <div className="cert-upload-row">
                            <label htmlFor="QAoftp2Cert">Certificate<span style={{ color: 'red' }}>*</span></label>
                            <input type="file" id="QAoftp2Cert" name="QAoftp2Cert" onChange={handleFileChange} required />
                          </div>
                        </div>
                      )}

                      {formData.QAprotocol === 'SFTP' && (
                        <div className="form-section">
                          <label>Host<span style={{ color: 'red' }}>*</span></label>
                          <input type="text" name="QAsftphost" value={formData.QAsftphost || ''} onChange={handleInputChange} required />
                          <label>Port<span style={{ color: 'red' }}>*</span></label>
                          <input type="text" name="QAport" value={formData.QAport || ''} onChange={handleInputChange} required />
                          <label>Username<span style={{ color: 'red' }}>*</span></label>
                          <input type="text" name="QAusername" value={formData.QAusername || ''} onChange={handleInputChange} required />

                          <label>Authentication Type<span style={{ color: 'red' }}>*</span></label>
                          <select name="QAauthType" value={formData.QAauthType || ''} onChange={handleInputChange} required>
                            <option value="">--Select--</option>
                            <option value="Password">Password</option>
                            <option value="Key">Key</option>
                          </select>

                          {formData.QAauthType === 'Password' && (
                            <>
                              <label>Password<span style={{ color: 'red' }}>*</span></label>
                              <input type="password" name="QAsftpPassword" value={formData.QAsftpPassword || ''} onChange={handleInputChange} required />
                            </>
                          )}

                          <label>Directory<span style={{ color: 'red' }}>*</span></label>
                          <input type="text" name="QAdirectory" value={formData.QAdirectory || ''} onChange={handleInputChange} required />
                        </div>
                      )}

                      {formData.QAprotocol === 'Others' && (
                        <div className="form-section">
                          <label>Description<span style={{ color: 'red' }}>*</span></label>
                          <input type="text" name="QAOtherProtocolDescription" value={formData.QAOtherProtocolDescription || ''} onChange={handleInputChange} required />

                          <div className="cert-upload-row">
                            <label htmlFor="connectivityDetails">Connectivity Parameters Details<span style={{ color: 'red' }}>*</span></label>
                            <input type="file" id="connectivityDetails" name="QAconnectivityDetails" onChange={handleFileChange} required />
                          </div>
                        </div>
                      )}
                    </>
                  )}
                </div>

                <div className="form-section">
                  <h4
                    className="configuration-section-title"
                    style={{ cursor: 'pointer', display: 'flex', alignItems: 'center', userSelect: 'none' }}
                    onClick={() => setProdOpen(open => !open)}>
                    <span style={{
                      display: 'inline-block',
                      transition: 'transform 0.2s',
                      transform: prodOpen ? 'rotate(90deg)' : 'rotate(0deg)',
                      marginRight: 8,
                      fontSize: '1.2em'
                    }}>▶</span>
                    Production Configurations
                  </h4>
                  {/* {prodOpen && (<> */}
                  <div style={{ display: prodOpen ? 'block' : 'none' }}>
                    <div className="form-section">

                      <label>EDI Standard<span style={{ color: 'red' }}>*</span></label>
                      <div className="chip-group">
                        {["ANSI X12", "EDIFACT", "VDA", "Others"].map(option => (
                          <label
                            key={option}
                            className={`chip ${formData.ediStandard === option ? "selected" : ""}`}
                          >

                            <input
                              type="radio"
                              name="ediStandard"
                              value={option}
                              checked={formData.ediStandard === option}
                              onChange={e => {
                                resetEdiFields('');
                                setFormData(prev => ({
                                  ...prev,
                                  ediStandard: e.target.value,
                                  specification: e.target.value
                                }));
                              }}
                              required
                            />
                            {option}
                          </label>
                        ))}
                      </div>
                    </div>

                    {formData.ediStandard === 'ANSI X12' && (
                      <>

                        <label>ISA ID Qualifier<span style={{ color: 'red' }}>*</span></label>
                        <input type="text" name='isaIdQualifier' value={formData.isaIdQualifier} onChange={handleInputChange} required />

                        <label>EDI ID<span style={{ color: 'red' }}>*</span></label>
                        <input type="text" name='isaId' value={formData.isaId} onChange={handleInputChange} required />

                        <label>GS ID<span style={{ color: 'red' }}>*</span></label>
                        <input type="text" name='gsId' value={formData.gsId} onChange={handleInputChange} required />

                        <label>Transaction Types<span style={{ color: 'red' }}>*</span></label>
                        <input type="text" name='transactionTypes' value={formData.transactionTypes} onChange={handleInputChange} required />

<label>Transaction Version</label>
                      <input type="text" name='transactionVersion' value={formData.transactionVersion} onChange={handleInputChange}  />


                        <label>Supplier/Vendor ID<span style={{ color: 'red' }}>*</span></label>
                        <input type="text" name='vendorId' value={formData.vendorId} onChange={handleInputChange} required />

                        <label>Plant ID<span style={{ color: 'red' }}>*</span></label>
                        <input type="text" name='customerPlantId' value={formData.customerPlantId} onChange={handleInputChange} required />

                      </>
                    )}

                    {formData.ediStandard === 'EDIFACT' && (
                      <>

                        <label>UNB ID Qualifier<span style={{ color: 'red' }}>*</span></label>
                        <input type="text" name='unbIdQualifier' value={formData.unbIdQualifier} onChange={handleInputChange} required />

                        <label>UNB ID<span style={{ color: 'red' }}>*</span></label>
                        <input type="text" name='unbId' value={formData.unbId} onChange={handleInputChange} required />

                        <label>Transaction Types<span style={{ color: 'red' }}>*</span></label>
                        <input type="text" name='transactionTypes' value={formData.transactionTypes} onChange={handleInputChange} required />

<label>Transaction Version</label>
                      <input type="text" name='transactionVersion' value={formData.transactionVersion} onChange={handleInputChange}  />


                        <label>Supplier/Vendor ID<span style={{ color: 'red' }}>*</span></label>
                        <input type="text" name='vendorId' value={formData.vendorId} onChange={handleInputChange} required />

                        <label>Plant ID<span style={{ color: 'red' }}>*</span></label>
                        <input type="text" name='customerPlantId' value={formData.customerPlantId} onChange={handleInputChange} required />

                      </>
                    )}

                    {formData.ediStandard === 'VDA' && (
                      <>

                        <label>VDA ID<span style={{ color: 'red' }}>*</span></label>
                        <input type="text" name='vdaId' value={formData.vdaId} onChange={handleInputChange} />

                        <label>Transaction Types<span style={{ color: 'red' }}>*</span></label>
                        <input type="text" name='transactionTypes' value={formData.transactionTypes} onChange={handleInputChange} required />

<label>Transaction Version</label>
                      <input type="text" name='transactionVersion' value={formData.transactionVersion} onChange={handleInputChange}  />


                        <label>Supplier/Vendor ID<span style={{ color: 'red' }}>*</span></label>
                        <input type="text" name='vendorId' value={formData.vendorId} onChange={handleInputChange} required />

                        <label>Plant ID<span style={{ color: 'red' }}>*</span></label>
                        <input type="text" name='customerPlantId' value={formData.customerPlantId} onChange={handleInputChange} required />

                      </>
                    )}

                    {formData.ediStandard === 'Others' && (
                      <>
                        <label>File Format [XML/CSV/FlatFile]<span style={{ color: 'red' }}>*</span></label>
                        <input type="text" name='fileFormat' value={formData.fileFormat} onChange={handleInputChange} required />


                      </>
                    )}
                    <label>Upload Sample File</label>
                    {sampleFileInputs.map((id, index) => (
                      <div
                        key={id}
                        className={`spec-upload-row${highlightSampleRow && index === sampleFileInputs.length - 1 && !sampleFiles[index] ? ' spec-upload-row-error' : ''}`}
                        style={{ display: 'flex', alignItems: 'center', gap: '8px' }}
                      >
                        <input
                          type="file"
                          name="samplePath"
                          onChange={e => handleSampleFileChange(e, index)}
                          style={{ flex: 1 }}
                        />
                        {/* Show delete button only if more than one row */}
                        {sampleFileInputs.length > 1 && (
                          <button
                            type="button"
                            className="icon-btn delete-btn"
                            title="Delete file"
                            onClick={() => handleRemoveSampleFileInput(index)}
                            style={{ marginLeft: 4 }}
                          >
                            <span role="img" aria-label="delete">&#128465;</span>
                          </button>
                        )}
                        {/* Add Button */}
                        <button
                          type="button"
                          className="icon-btn add-btn"
                          title="Add new file"
                          onClick={() => {
                            if (!sampleFiles[index]) {
                              setHighlightSampleRow(true);
                              setSampleWarning('Please upload a file before adding a new entry.');
                              setTimeout(() => {
                                setHighlightSampleRow(false);
                                setSampleWarning('');
                              }, 2000); // Hide warning after 3 seconds
                            } else {
                              setHighlightSampleRow(false);
                              setSampleWarning('');
                              handleAddSampleFileInput();
                            }
                          }}
                          style={{ marginLeft: 4 }}
                        >
                          <span style={{ fontWeight: 'bold', fontSize: '1.2em' }}>+</span>
                        </button>
                      </div>
                    ))}
                    {sampleWarning && (
                      <div className="sample-warning">
                        {sampleWarning}
                      </div>
                    )}
                    <label>Specification Files</label>
                    {specFileInputs.map((id, index) => (
                      <div
                        key={id}
                        className={`spec-upload-row${highlightSpecRow && index === specFileInputs.length - 1 && !specFiles[index] ? ' spec-upload-row-error' : ''}`}
                        style={{ display: 'flex', alignItems: 'center', gap: '8px' }}
                      >
                        <input
                          type="file"
                          name="specPath"
                          onChange={e => handleSpecFileChange(e, index)}
                          style={{ flex: 1 }}
                        />
                        {/* Show selected file name if present */}
                        {specFiles[index] && (
                          <span style={{ marginLeft: 8 }}>
                            {specFiles[index].name || (typeof specFiles[index] === 'string' ? specFiles[index] : '')}
                          </span>
                        )}
                        {/* Show delete button only if more than one row */}
                        {specFileInputs.length > 1 && (
                          <button
                            type="button"
                            className="icon-btn delete-btn"
                            title="Delete this row"
                            onClick={() => handleRemoveSpecFileInput(index)}
                            style={{ marginLeft: 4 }}
                          >
                            <span role="img" aria-label="delete">&#128465;</span>
                          </button>
                        )}
                        {/* Add Button */}
                        <button
                          type="button"
                          className="icon-btn add-btn"
                          title="Add new specification row"
                          onClick={() => {
                            if (!specFiles[index]) {
                              // Show warning for spec files
                              setHighlightSpecRow(true);
                              setSpecWarning('Please upload a file before adding a new row.');
                              setTimeout(() => {
                                setHighlightSpecRow(false);
                                setSpecWarning('');
                              }, 2000);
                            } else {
                              setHighlightSpecRow(false);
                              setSpecWarning('');
                              handleAddSpecFileInput();
                            }
                          }}
                          style={{ marginLeft: 4 }}
                        >
                          <span style={{ fontWeight: 'bold', fontSize: '1.2em' }}>+</span>
                        </button>
                      </div>
                    ))}

                    {specWarning && (
                      <div className="spec-warning">
                        {specWarning}
                      </div>
                    )}

                    <div className="form-section remarks-section">
                      <label className="remark-section-title">Remarks/Any special guidelines</label>
                      <div className="remarks-subsection">
                        <div>
                          <label htmlFor="remarksDescription">Description</label>
                          <input
                            type="text"
                            id="remarksDescription"
                            name="remarksDescription"
                            value={formData.remarksDescription}
                            onChange={handleInputChange}
                          />
                        </div>
                        <div className="cert-upload-row">
                          <label htmlFor="remarksFile">Upload file:</label>
                          <input
                            type="file"
                            id="remarksFile"
                            name="remarksFile"
                            onChange={handleFileChange}
                          />
                        </div>
                      </div>
                    </div>

                    <label>Communication Protocol<span style={{ color: 'red' }}>*</span></label>
                    <select name="protocol" value={protocol} onChange={e => {
                      resetProtocolFields('');
                      handleInputChange(e);
                    }} required>
                      <option value="">--Select--</option>
                      <option value="AS2">AS2</option>
                      <option value="SFTP">SFTP</option>
                      <option value="OFTP2">OFTP2</option>
                      <option value="Others">Others</option>
                    </select>

                    {protocol === 'AS2' && (
                      <div className="form-section">
                        <label>AS2 ID<span style={{ color: 'red' }}>*</span></label>
                        <input type="text" name="as2Id" value={formData.as2Id} onChange={handleInputChange} required />

                        <label>Endpoint<span style={{ color: 'red' }}>*</span></label>
                        <input type="text" name="endpoint" value={formData.endpoint} onChange={handleInputChange} required />

                        <label>SSL<span style={{ color: 'red' }}>*</span></label>
                        <select name="ssl" value={ssl} onChange={handleInputChange} required>
                          <option value="">--Select--</option>
                          <option value="Yes">Yes</option>
                          <option value="No">No</option>
                        </select>

                        {ssl === 'Yes' && (
                          <>
                            <div className="cert-upload-row">
                              <label htmlFor="sslCert">Certificate<span style={{ color: 'red' }}>*</span></label>
                              <input type="file" id="sslCert" name="sslCert" onChange={handleFileChange} required />
                            </div>

                          </>
                        )}

                        <label>Payload Type<span style={{ color: 'red' }}>*</span></label>
                        <input type="text" name="payloadType" value={formData.payloadType} onChange={handleInputChange} required />

                        <label>Encryption Algorithm<span style={{ color: 'red' }}>*</span></label>
                        <input type="text" name="encryptionAlgo" value={formData.encryptionAlgo} onChange={handleInputChange} required />

                        <label>Signing Algorithm<span style={{ color: 'red' }}>*</span></label>
                        <input type="text" name="signingAlgo" value={formData.signingAlgo} onChange={handleInputChange} required />

                        <label>MDN Mode<span style={{ color: 'red' }}>*</span></label>
                        <select name="mdnMode" value={formData.mdnMode} onChange={handleInputChange} required>
                          <option value="">--Select--</option>
                          <option value="Synchronous">Synchronous</option>
                          <option value="Asynchronous">Asynchronous</option>
                        </select>

                        <div className="cert-upload-row">
                          <label htmlFor="exchangeCert">Exchange Certificate<span style={{ color: 'red' }}>*</span></label>
                          <input type="file" id="exchangeCert" name="exchangeCert" onChange={handleFileChange} required />
                        </div>
                        <div className="cert-upload-row">
                          <label htmlFor="signingCert">Signing Certificate<span style={{ color: 'red' }}>*</span></label>
                          <input type="file" id="signingCert" name="signingCert" onChange={handleFileChange} required />
                        </div>
                      </div>
                    )}

                    {protocol === 'OFTP2' && (
                      <div className="form-section">
                        <label>SSID<span style={{ color: 'red' }}>*</span></label>
                        <input type="text" name="ssid" value={formData.ssid} onChange={handleInputChange} required />
                        <label>SFID<span style={{ color: 'red' }}>*</span></label>
                        <input type="text" name="sfid" value={formData.sfid} onChange={handleInputChange} required />
                        <label>Password<span style={{ color: 'red' }}>*</span></label>
                        <input type="password" name="oftp2Password" value={formData.oftp2Password} onChange={handleInputChange} required />
                        <label>Host<span style={{ color: 'red' }}>*</span></label>
                        <input type="text" name="host" value={formData.host} onChange={handleInputChange} required />
                        <label>Port<span style={{ color: 'red' }}>*</span></label>
                        <input type="text" name="port" value={formData.port} onChange={handleInputChange} required />
                        <div className="cert-upload-row">
                          <label htmlFor="oftp2Cert">Certificate<span style={{ color: 'red' }}>*</span></label>
                          <input type="file" id="oftp2Cert" name="oftp2Cert" onChange={handleFileChange} required />
                        </div>
                      </div>
                    )}

                    {protocol === 'SFTP' && (
                      <div className="form-section">
                        <label>Host<span style={{ color: 'red' }}>*</span></label>
                        <input type="text" name="sftphost" value={formData.sftphost} onChange={handleInputChange} required />
                        <label>Port<span style={{ color: 'red' }}>*</span></label>
                        <input type="text" name="port" value={formData.port} onChange={handleInputChange} required />
                        <label>Username<span style={{ color: 'red' }}>*</span></label>
                        <input type="text" name="username" value={formData.username} onChange={handleInputChange} required />

                        <label>Authentication Type<span style={{ color: 'red' }}>*</span></label>
                        <select name="authType" value={authType} onChange={handleInputChange} required>
                          <option value="">--Select--</option>
                          <option value="Password">Password</option>
                          <option value="Key">Key</option>
                        </select>

                        {authType === 'Password' && (
                          <>
                            <label>Password<span style={{ color: 'red' }}>*</span></label>
                            <input type="password" name="sftpPassword" value={formData.sftpPassword} onChange={handleInputChange} required />
                          </>
                        )}

                        <label>Directory<span style={{ color: 'red' }}>*</span></label>
                        <input type="text" name="directory" value={formData.directory} onChange={handleInputChange} required />
                      </div>
                    )}

                    {protocol === 'Others' && (
                      <div className="form-section">
                        <label>Description<span style={{ color: 'red' }}>*</span></label>
                        <input type="text" name="otherProtocolDescription" value={formData.otherProtocolDescription} onChange={handleInputChange} required />

                        <div className="cert-upload-row">
                          <label htmlFor="connectivityDetails">Connectivity Parameters Details<span style={{ color: 'red' }}>*</span></label>
                          <input type="file" id="connectivityDetails" name="connectivityDetails" onChange={handleFileChange} required />
                        </div>
                      </div>
                    )}
                  </div>
                  {/* </> */}
                  {/* )} */}
                </div>
              </>
            )}
          </div>

          <p className="mandatory-remark">
            <b>Note:</b> Kindly verify the information provided above before submitting.
          </p>
          <div>
            <button className='preview-button' type="submit">
              Preview and Submit
            </button>

          </div>

        </form>)}

      {showPreview && (
        <div className="preview-section" style={{ background: '#f9fafb', padding: 24, borderRadius: 8 }}>

          <div style={{ marginBottom: 16 }}>
            <h4>Partner Details</h4>
            <div className="preview-field-row">
              <span className="preview-label">Partner Name:</span>
              <span className="preview-value">{showValue(formData.partnerName)}</span>
            </div>
            <div className="preview-field-row">
              <span className="preview-label">shipTo:</span>
              <span className="preview-value">{showValue(formData.shipTo)}</span>
            </div>
            <div className="preview-field-row">
              <span className="preview-label">soldTo:</span>
              <span className="preview-value">{showValue(formData.soldTo)}</span>
            </div>
            <h4>Contact Details</h4>
            <div className="preview-field-row">
              <span className="preview-label">Technical Contact:</span>
              <span className="preview-value">{showValue(formData.technicalContactDetails)}</span>
            </div>
            <div className="preview-field-row">
              <span className="preview-label">Business Contact:</span>
              <span className="preview-value">{showValue(formData.businessContactDetails)}</span>
            </div>
            <div className="preview-field-row">
              <span className="preview-label">TE Counterpart Contact:</span>
              <span className="preview-value">{showValue(formData.teCounterpartContactDetails)}</span>
            </div>

            <div className="preview-field-row">
              <span className="preview-label">Are the configurations for both QA and Production environment same?:</span>
              <span className="preview-value">{showValue(formData.envSame)}</span>
            </div>
            {/* QA Section */}
            {formData.envSame === 'No' && (
              <>
                <h4>QA/UAT/Non-Production Configurations</h4>
                <div className="preview-field-row">
                  <span className="preview-label">EDI Standard:</span>
                  <span className="preview-value">{showValue(formData.QAediStandard)}</span>
                </div>
                {formData.QAediStandard === 'ANSI X12' && (
                  <>
                    <div className="preview-field-row">
                      <span className="preview-label">ISA ID Qualifier:</span>
                      <span className="preview-value">{showValue(formData.QAisaIdQualifier)}</span>
                    </div>
                    <div className="preview-field-row">
                      <span className="preview-label">ISA ID:</span>
                      <span className="preview-value">{showValue(formData.QAisaId)}</span>
                    </div>
                    <div className="preview-field-row">
                      <span className="preview-label">GS ID:</span>
                      <span className="preview-value">{showValue(formData.QAgsId)}</span>
                    </div>
                    <div className="preview-field-row">
                      <span className="preview-label">Transaction Types:</span>
                      <span className="preview-value">{showValue(formData.QAtransactionTypes)}</span>
                    </div>
                    <div className="preview-field-row">
                      <span className="preview-label">Transaction Version:</span>
                      <span className="preview-value">{showValue(formData.QATransactionVersion)}</span>
                    </div>
                    <div className="preview-field-row">
                      <span className="preview-label">Supplier/Vendor ID:</span>
                      <span className="preview-value">{showValue(formData.QAvendorId)}</span>
                    </div>
                    <div className="preview-field-row">
                      <span className="preview-label">Plant ID:</span>
                      <span className="preview-value">{showValue(formData.QACustomerPlantId)}</span>
                    </div>
                  </>
                )}
                {formData.QAediStandard === 'EDIFACT' && (
                  <>
                    <div className="preview-field-row">
                      <span className="preview-label">UNB ID Qualifier:</span>
                      <span className="preview-value">{showValue(formData.QAunbIdQualifier)}</span>
                    </div>
                    <div className="preview-field-row">
                      <span className="preview-label">UNB ID:</span>
                      <span className="preview-value">{showValue(formData.QAunbId)}</span>
                    </div>
                    <div className="preview-field-row">
                      <span className="preview-label">Transaction Types:</span>
                      <span className="preview-value">{showValue(formData.QAtransactionTypes)}</span>
                    </div>
                    <div className="preview-field-row">
                      <span className="preview-label">Transaction Version:</span>
                      <span className="preview-value">{showValue(formData.QATransactionVersion)}</span>
                    </div>
                    <div className="preview-field-row">
                      <span className="preview-label">Supplier/Vendor ID:</span>
                      <span className="preview-value">{showValue(formData.QAvendorId)}</span>
                    </div>
                    <div className="preview-field-row">
                      <span className="preview-label">Plant ID:</span>
                      <span className="preview-value">{showValue(formData.QACustomerPlantId)}</span>
                    </div>
                  </>
                )}
                {formData.QAediStandard === 'VDA' && (
                  <>
                    <div className="preview-field-row">
                      <span className="preview-label">VDA ID:</span>
                      <span className="preview-value">{showValue(formData.QAvdaId)}</span>
                    </div>
                    <div className="preview-field-row">
                      <span className="preview-label">Transaction Types:</span>
                      <span className="preview-value">{showValue(formData.QAtransactionTypes)}</span>
                    </div>
                    <div className="preview-field-row">
                      <span className="preview-label">Transaction Version:</span>
                      <span className="preview-value">{showValue(formData.QATransactionVersion)}</span>
                    </div>
                    <div className="preview-field-row">
                      <span className="preview-label">Supplier/Vendor ID:</span>
                      <span className="preview-value">{showValue(formData.QAvendorId)}</span>
                    </div>
                    <div className="preview-field-row">
                      <span className="preview-label">Plant ID:</span>
                      <span className="preview-value">{showValue(formData.QACustomerPlantId)}</span>
                    </div>
                  </>
                )}
                {formData.QAediStandard === 'Others' && (
                  <div className="preview-field-row">
                    <span className="preview-label">File Format:</span>
                    <span className="preview-value">{showValue(formData.QAfileFormat)}</span>
                  </div>
                )}
                <div className="preview-field-row">
                  <span className="preview-label">QA Remarks Description:</span>
                  <span className="preview-value">{showValue(formData.QARemarksDescription)}</span>
                </div>

                <div className="preview-field-row">
                  <span className="preview-label">QA Remarks File:</span>
                  <span className="preview-value">
                    {/* {(formData.QARemarksFile instanceof File) ||
                      (typeof formData.QARemarksFile === 'string' && formData.QARemarksFile.trim() !== '')
                      ? 'Yes'
                      : 'No'} */}

                    {getFileNameOrValue(formData.QARemarksFile)}
                  </span>
                </div>
                <div className="preview-field-row">
                  <span className="preview-label">QA Specification File:</span>
                  <span className="preview-value">
                    {qaSpecFiles && qaSpecFiles.some(f => f instanceof File || (typeof f === 'string' && f))
                      ? 'Yes'
                      : 'No'}

                  {/* Show QA Specification file names */}
                  {qaSpecFiles && qaSpecFiles.some(f => f) && (
                  <ul style={{ margin: 0, paddingLeft: 20 }}>
                    {qaSpecFiles.map((f, i) =>
                      f ? (
                        <li key={i}>{f.name || (typeof f === 'string' ? f : '')}</li>
                      ) : 'No'
                    )}
                  </ul>
                )}
                  </span>
                </div>
                <div className="preview-field-row">
                  <span className="preview-label">QA Sample File:</span>
                  <span className="preview-value">
                    {qaSampleFiles && qaSampleFiles.some(f => f instanceof File || (typeof f === 'string' && f))
                      ? 'Yes'
                      : 'No'}
                      {/* Show QA Sample file names */}
                {qaSampleFiles && qaSampleFiles.some(f => f) && (
                  <ul style={{ margin: 0, paddingLeft: 20 }}>
                    {qaSampleFiles.map((f, i) =>
                      f ? (
                        <li key={i}>{f.name || (typeof f === 'string' ? f : '')}</li>
                      ) : null
                    )}
                  </ul>
                )}
                  </span>
                </div>
                
                <div className="preview-field-row">
                  <span className="preview-label">QA Communication Protocol:</span>
                  <span className="preview-value">{showValue(formData.QAprotocol)}</span>
                </div>

                {formData.QAprotocol === 'AS2' && (
                  <>
                    <div className="preview-field-row">
                      <span className="preview-label">AS2 ID:</span>
                      <span className="preview-value">{showValue(formData.QAas2Id)}</span>
                    </div>
                    <div className="preview-field-row">
                      <span className="preview-label">Endpoint:</span>
                      <span className="preview-value">{showValue(formData.QAendpoint)}</span>
                    </div>
                    <div className="preview-field-row">
                      <span className="preview-label">SSL:</span>
                      <span className="preview-value">{showValue(formData.QAssl)}</span>
                    </div>
                    <div className="preview-field-row">
                      <span className="preview-label">Payload Type:</span>
                      <span className="preview-value">{showValue(formData.QApayloadType)}</span>
                    </div>
                    <div className="preview-field-row">
                      <span className="preview-label">Encryption Algorithm:</span>
                      <span className="preview-value">{showValue(formData.QAencryptionAlgo)}</span>
                    </div>
                    <div className="preview-field-row">
                      <span className="preview-label">Signing Algorithm:</span>
                      <span className="preview-value">{showValue(formData.QAsigningAlgo)}</span>
                    </div>
                    <div className="preview-field-row">
                      <span className="preview-label">MDN Mode:</span>
                      <span className="preview-value">{showValue(formData.QAmdnMode)}</span>
                    </div>
                    <div className="preview-field-row">
                      <span className="preview-label">QA SSL Certificate:</span>
                      <span className="preview-value">
                        {/* {(formData.QAsslCert instanceof File) ||
                          (typeof formData.QAsslCert === 'string' && formData.QAsslCert.trim() !== '')
                          ? 'Yes'
                          : 'No'} */}

                      {getFileNameOrValue(formData.QAsslCert)}
                      </span>
                    </div>
                    <div className="preview-field-row">
                      <span className="preview-label">QA Exchange Certificate:</span>
                      <span className="preview-value">
                        {/* {(formData.QAexchangeCert instanceof File) ||
                          (typeof formData.QAexchangeCert === 'string' && formData.QAexchangeCert.trim() !== '')
                          ? 'Yes'
                          : 'No'} */}

                      {getFileNameOrValue(formData.QAexchangeCert)}
                      </span>
                    </div>
                    <div className="preview-field-row">
                      <span className="preview-label">QA Signing Certificate:</span>
                      <span className="preview-value">
                        {/* {(formData.QAsigningCert instanceof File) ||
                          (typeof formData.QAsigningCert === 'string' && formData.QAsigningCert.trim() !== '')
                          ? 'Yes'
                          : 'No'} */}

                      {getFileNameOrValue(formData.QAsigningCert)}
                      </span>
                    </div>
                  </>
                )}
                {/* SFTP */}
                {formData.QAprotocol === 'SFTP' && (
                  <>
                    <div className="preview-field-row">
                      <span className="preview-label">Host:</span>
                      <span className="preview-value">{showValue(formData.QAsftphost)}</span>
                    </div>
                    <div className="preview-field-row">
                      <span className="preview-label">Port:</span>
                      <span className="preview-value">{showValue(formData.QAport)}</span>
                    </div>
                    <div className="preview-field-row">
                      <span className="preview-label">Username:</span>
                      <span className="preview-value">{showValue(formData.QAusername)}</span>
                    </div>
                    <div className="preview-field-row">
                      <span className="preview-label">Authentication Type:</span>
                      <span className="preview-value">{showValue(formData.QAauthType)}</span>
                    </div>
                    {formData.QAauthType === 'Password' && (
                      <div className="preview-field-row">
                        <span className="preview-label">Password:</span>
                        <span className="preview-value">{showValue(formData.QAsftpPassword)}</span>
                      </div>
                    )}
                    <div className="preview-field-row">
                      <span className="preview-label">Directory:</span>
                      <span className="preview-value">{showValue(formData.QAdirectory)}</span>
                    </div>
                  </>
                )}
                {/* OFTP2 */}
                {formData.QAprotocol === 'OFTP2' && (
                  <>
                    <div className="preview-field-row">
                      <span className="preview-label">SSID:</span>
                      <span className="preview-value">{showValue(formData.QAssid)}</span>
                    </div>
                    <div className="preview-field-row">
                      <span className="preview-label">SFID:</span>
                      <span className="preview-value">{showValue(formData.QAsfid)}</span>
                    </div>
                    <div className="preview-field-row">
                      <span className="preview-label">Password:</span>
                      <span className="preview-value">{showValue(formData.QAoftp2Password)}</span>
                    </div>
                    <div className="preview-field-row">
                      <span className="preview-label">Host:</span>
                      <span className="preview-value">{showValue(formData.QAhost)}</span>
                    </div>
                    <div className="preview-field-row">
                      <span className="preview-label">Port:</span>
                      <span className="preview-value">{showValue(formData.QAport)}</span>
                    </div>
                    <div className="preview-field-row">
                      <span className="preview-label">Certificate:</span>
                      <span className="preview-value">
                        {/* {(formData.QAoftp2Cert instanceof File) ||
                          (typeof formData.QAoftp2Cert === 'string' && formData.QAoftp2Cert.trim() !== '')
                          ? 'Yes'
                          : 'No'} */}

                      {getFileNameOrValue(formData.QAoftp2Cert)}
                      </span>
                    </div>

                  </>
                )}

                {/* Others */}
                {formData.QAprotocol === 'Others' && (
                  <>
                    <div className="preview-field-row">
                      <span className="preview-label">Description:</span>
                      <span className="preview-value">{showValue(formData.QAOtherProtocolDescription)}</span>
                    </div>
                    <div className="preview-field-row">
                      <span className="preview-label">Connectivity Parameters Details:</span>
                      <span className="preview-value">
                        {/* {(formData.QAconnectivityDetails instanceof File) ||
                          (typeof formData.QAconnectivityDetails === 'string' && formData.QAconnectivityDetails.trim() !== '')
                          ? 'Yes'
                          : 'No'} */}

                      {getFileNameOrValue(formData.QAconnectivityDetails)}
                      </span>
                    </div>
                  </>
                )}





              </>
            )}
            {/* Production Section */}
            <h4>Production Configurations</h4>
            <div className="preview-field-row">
              <span className="preview-label">EDI Standard:</span>
              <span className="preview-value">{showValue(formData.ediStandard)}</span>
            </div>
            {formData.ediStandard === 'ANSI X12' && (
              <>
                <div className="preview-field-row">
                  <span className="preview-label">ISA ID Qualifier:</span>
                  <span className="preview-value">{showValue(formData.isaIdQualifier)}</span>
                </div>
                <div className="preview-field-row">
                  <span className="preview-label">ISA ID:</span>
                  <span className="preview-value">{showValue(formData.isaId)}</span>
                </div>
                <div className="preview-field-row">
                  <span className="preview-label">GS ID:</span>
                  <span className="preview-value">{showValue(formData.gsId)}</span>
                </div>
                <div className="preview-field-row">
                  <span className="preview-label">Transaction Types:</span>
                  <span className="preview-value">{showValue(formData.transactionTypes)}</span>
                </div>
                <div className="preview-field-row">
                      <span className="preview-label">Transaction Version:</span>
                      <span className="preview-value">{showValue(formData.transactionVersion)}</span>
                    </div>
                <div className="preview-field-row">
                  <span className="preview-label">Supplier/Vendor ID:</span>
                  <span className="preview-value">{showValue(formData.vendorId)}</span>
                </div>
                <div className="preview-field-row">
                  <span className="preview-label">Plant ID:</span>
                  <span className="preview-value">{showValue(formData.customerPlantId)}</span>
                </div>
              </>
            )}
            {formData.ediStandard === 'EDIFACT' && (
              <>
                <div className="preview-field-row">
                  <span className="preview-label">UNB ID Qualifier:</span>
                  <span className="preview-value">{showValue(formData.unbIdQualifier)}</span>
                </div>
                <div className="preview-field-row">
                  <span className="preview-label">UNB ID:</span>
                  <span className="preview-value">{showValue(formData.unbId)}</span>
                </div>
                <div className="preview-field-row">
                  <span className="preview-label">Transaction Types:</span>
                  <span className="preview-value">{showValue(formData.transactionTypes)}</span>
                </div>
                <div className="preview-field-row">
                      <span className="preview-label">Transaction Version:</span>
                      <span className="preview-value">{showValue(formData.transactionVersion)}</span>
                    </div>
                <div className="preview-field-row">
                  <span className="preview-label">Supplier/Vendor ID:</span>
                  <span className="preview-value">{showValue(formData.vendorId)}</span>
                </div>
                <div className="preview-field-row">
                  <span className="preview-label">Plant ID:</span>
                  <span className="preview-value">{showValue(formData.customerPlantId)}</span>
                </div>
              </>
            )}
            {formData.ediStandard === 'VDA' && (
              <>
                <div className="preview-field-row">
                  <span className="preview-label">VDA ID:</span>
                  <span className="preview-value">{showValue(formData.vdaId)}</span>
                </div>
                <div className="preview-field-row">
                  <span className="preview-label">Transaction Types:</span>
                  <span className="preview-value">{showValue(formData.transactionTypes)}</span>
                </div>
                <div className="preview-field-row">
                      <span className="preview-label">Transaction Version:</span>
                      <span className="preview-value">{showValue(formData.transactionVersion)}</span>
                    </div>
                <div className="preview-field-row">
                  <span className="preview-label">Supplier/Vendor ID:</span>
                  <span className="preview-value">{showValue(formData.vendorId)}</span>
                </div>
                <div className="preview-field-row">
                  <span className="preview-label">Plant ID:</span>
                  <span className="preview-value">{showValue(formData.customerPlantId)}</span>
                </div>
              </>
            )}
            {formData.ediStandard === 'Others' && (
              <div className="preview-field-row">
                <span className="preview-label">File Format:</span>
                <span className="preview-value">{showValue(formData.fileFormat)}</span>
              </div>
            )}

            <div className="preview-field-row">
              <span className="preview-label">Remarks Description:</span>
              <span className="preview-value">{showValue(formData.remarksDescription)}</span>
            </div>

            <div className="preview-field-row">
              <span className="preview-label">Remarks File:</span>
              <span className="preview-value">
                {/* {(formData.remarksFile instanceof File) ||
                  (typeof formData.remarksFile === 'string' && formData.remarksFile.trim() !== '')
                  ? 'Yes'
                  : 'No'} */}

                  {getFileNameOrValue(formData.remarksFile)}
              </span>

            </div>
            <div className="preview-field-row">
                  <span className="preview-label">Specification File:</span>
                  <span className="preview-value">
                    {specFiles && specFiles.some(f => f instanceof File || (typeof f === 'string' && f))
                      ? 'Yes'
                      : 'No'}
                      {renderFileList(specFiles)}
                  </span>
                </div>
                <div className="preview-field-row">
                  <span className="preview-label">Sample File:</span>
                  <span className="preview-value">
                    {sampleFiles && sampleFiles.some(f => f instanceof File || (typeof f === 'string' && f))
                      ? 'Yes'
                      : 'No'}
                      {renderFileList(sampleFiles)}
                  </span>
                </div>
            {/* <div className="preview-field-row">
              <span className="preview-label">Sample File:</span>
              <span className="preview-value">
                {Array.isArray(formData.samplePath) && formData.samplePath.some(f => f instanceof File || (typeof f === 'string' && f.trim() !== ''))
                  ? 'Yes'
                  : 'No'}
              </span>
            </div> */}

            <div className="preview-field-row">
              <span className="preview-label">Production Communication Protocol:</span>
              <span className="preview-value">{showValue(formData.protocol)}</span>
            </div>

            {formData.protocol === 'AS2' && (
              <>
                <div className="preview-field-row">
                  <span className="preview-label">AS2 ID:</span>
                  <span className="preview-value">{showValue(formData.as2Id)}</span>
                </div>
                <div className="preview-field-row">
                  <span className="preview-label">Endpoint:</span>
                  <span className="preview-value">{showValue(formData.endpoint)}</span>
                </div>
                <div className="preview-field-row">
                  <span className="preview-label">SSL:</span>
                  <span className="preview-value">{showValue(formData.ssl)}</span>
                </div>
                <div className="preview-field-row">
                  <span className="preview-label">Payload Type:</span>
                  <span className="preview-value">{showValue(formData.payloadType)}</span>
                </div>
                <div className="preview-field-row">
                  <span className="preview-label">Encryption Algorithm:</span>
                  <span className="preview-value">{showValue(formData.encryptionAlgo)}</span>
                </div>
                <div className="preview-field-row">
                  <span className="preview-label">Signing Algorithm:</span>
                  <span className="preview-value">{showValue(formData.signingAlgo)}</span>
                </div>
                <div className="preview-field-row">
                  <span className="preview-label">MDN Mode:</span>
                  <span className="preview-value">{showValue(formData.mdnMode)}</span>
                </div>
                <div className="preview-field-row">
                  <span className="preview-label">SSL Certificate:</span>
                  <span className="preview-value">
                    {/* {(formData.sslCert instanceof File) ||
                      (typeof formData.sslCert === 'string' && formData.sslCert.trim() !== '')
                      ? 'Yes'
                      : 'No'} */}

                      {getFileNameOrValue(formData.sslCert)}
                  </span>
                </div>
                <div className="preview-field-row">
                  <span className="preview-label">Exchange Certificate:</span>
                  <span className="preview-value">
                    {/* {(formData.exchangeCert instanceof File) ||
                      (typeof formData.exchangeCert === 'string' && formData.exchangeCert.trim() !== '')
                      ? 'Yes'
                      : 'No'} */}

                      {getFileNameOrValue(formData.exchangeCert)}
                  </span>
                </div>
                <div className="preview-field-row">
                  <span className="preview-label">Signing Certificate:</span>
                  <span className="preview-value">
                    {/* {(formData.signingCert instanceof File) ||
                      (typeof formData.signingCert === 'string' && formData.signingCert.trim() !== '')
                      ? 'Yes'
                      : 'No'} */}

                      {getFileNameOrValue(formData.signingCert)}
                  </span>
                </div>
              </>
            )}
            {/* SFTP */}
            {formData.protocol === 'SFTP' && (
              <>
                <div className="preview-field-row">
                  <span className="preview-label">Host:</span>
                  <span className="preview-value">{showValue(formData.sftphost)}</span>
                </div>
                <div className="preview-field-row">
                  <span className="preview-label">Port:</span>
                  <span className="preview-value">{showValue(formData.port)}</span>
                </div>
                <div className="preview-field-row">
                  <span className="preview-label">Username:</span>
                  <span className="preview-value">{showValue(formData.username)}</span>
                </div>
                <div className="preview-field-row">
                  <span className="preview-label">Authentication Type:</span>
                  <span className="preview-value">{showValue(formData.authType)}</span>
                </div>
                {formData.authType === 'Password' && (
                  <div className="preview-field-row">
                    <span className="preview-label">Password:</span>
                    <span className="preview-value">{showValue(formData.sftpPassword)}</span>
                  </div>
                )}
                <div className="preview-field-row">
                  <span className="preview-label">Directory:</span>
                  <span className="preview-value">{showValue(formData.directory)}</span>
                </div>
              </>
            )}
            {/* OFTP2 */}
            {formData.protocol === 'OFTP2' && (
              <>
                <div className="preview-field-row">
                  <span className="preview-label">SSID:</span>
                  <span className="preview-value">{showValue(formData.ssid)}</span>
                </div>
                <div className="preview-field-row">
                  <span className="preview-label">SFID:</span>
                  <span className="preview-value">{showValue(formData.sfid)}</span>
                </div>
                <div className="preview-field-row">
                  <span className="preview-label">Password:</span>
                  <span className="preview-value">{showValue(formData.oftp2Password)}</span>
                </div>
                <div className="preview-field-row">
                  <span className="preview-label">Host:</span>
                  <span className="preview-value">{showValue(formData.host)}</span>
                </div>
                <div className="preview-field-row">
                  <span className="preview-label">Port:</span>
                  <span className="preview-value">{showValue(formData.port)}</span>
                </div>
                <div className="preview-field-row">
                  <span className="preview-label">OFTP2 Certificate:</span>
                  <span className="preview-value">
                    {/* {formData.oftp2Cert instanceof File ? 'Yes' : 'No'} */}

                    {getFileNameOrValue(formData.oftp2Cert)}
                  </span>
                </div>
              </>
            )}

            {/* Others */}
            {formData.protocol === 'Others' && (
              <>
                <div className="preview-field-row">
                  <span className="preview-label">Description:</span>
                  <span className="preview-value">{showValue(formData.otherProtocolDescription)}</span>
                </div>
                <span className="preview-label">Description File:</span>
                <span className="preview-value">
                  {/* {(formData.connectivityDetails instanceof File) ||
                    (typeof formData.connectivityDetails === 'string' && formData.connectivityDetails.trim() !== '')
                    ? 'Yes'
                    : 'No'} */}

                    {getFileNameOrValue(formData.connectivityDetails)}
                </span>
              </>
            )}

          </div>
          <div className="preview-buttons">
            <button type="button" onClick={() => setShowPreview(false)}>
              Edit
            </button>
            <button type="button" onClick={() => setShowConfirm(true)}>
              Submit
            </button>
          </div>
          {showConfirm && (
            <div className="confirm-popup">
              <div className="confirm-popup-content">
                <p>Are you sure you want to submit?</p>
                <button
                  type="button"
                  onClick={handleSubmit}
                  style={{ marginRight: 8 }}
                >
                  Yes
                </button>
                <button type="button" onClick={() => setShowConfirm(false)}>
                  No
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default PartnerForm;