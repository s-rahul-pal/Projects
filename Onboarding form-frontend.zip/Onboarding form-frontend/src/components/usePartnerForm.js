import { useState } from 'react';
import axios from 'axios';

const usePartnerForm = () => {
  const [formData, setFormData] = useState({
    partnerName: '',
    contactDetails: '',
    ediStandard: [],
    specification: '',
    protocol: '',
    as2Id: '',
    endpoint: '',
    ssl: '',
    payloadType: '',
    encryptionAlgo: '',
    signingAlgo: '',
    mdnMode: '',
    ssid: '',
    sfid: '',
    oftp2Password: '',
    host: '',
    port: '',
    username: '',
    authType: '',
    sftpPassword: '',
    directory: '',
    sftphost: '',
    transactionTypes: '',
    isSimilarEnv: '',
    description: '',
    partnerCode: '',
    technicalContactDetails: '',
    businessContactDetails: '',
    teCounterpartContactDetails: '',
    fileFormat: '',
    remarksDescription: '',
    otherSpecificationDescription: '',

    // QA fields
    QAediStandard: [],
    QAspecification: '',
    QAprotocol: '',
    QAas2Id: '',
    QAendpoint: '',
    QAssl: '',
    QApayloadType: '',
    QAencryptionAlgo: '',
    QAsigningAlgo: '',
    QAmdnMode: '',
    QAssid: '',
    QAsfid: '',
    QAoftp2Password: '',
    QAhost: '',
    QAport: '',
    QAusername: '',
    QAauthType: '',
    QAsftpPassword: '',
    QAdirectory: '',
    QAsftphost: '',
    QAtransactionTypes: '',
    QAfileFormat: '',
    QARemarkDescription: '',
    QADescription: '',

  });

  
  const [specFileInputs, setSpecFileInputs] = useState([0]);
  const [files, setFiles] = useState({});
  const [specFiles, setSpecFiles] = useState([null]);
  const [qaSpecFileInputs, setQaSpecFileInputs] = useState([0]);
  const [qaSpecFiles, setQaSpecFiles] = useState([null]);
  const [specWarning, setSpecWarning] = useState('');
  const [highlightSpecRow, setHighlightSpecRow] = useState(false);
  const [envSame, setEnvSame] = useState('');
  const [envTab, setEnvTab] = useState('QA');
  const [sampleFileInputs, setSampleFileInputs] = useState([Date.now()]);
  const [sampleFiles, setSampleFiles] = useState([]);
  const [sampleWarning, setSampleWarning] = useState('');
  const [highlightSampleRow, setHighlightSampleRow] = useState(false);
  const [qaSampleFileInputs, setQaSampleFileInputs] = useState([Date.now()]);
  const [qaSampleFiles, setQaSampleFiles] = useState([]);
  const [qaSampleWarning, setQASampleWarning] = useState('');
  const [highlightQASampleRow, setHighlightQASampleRow] = useState(false);
  const [qaSpecWarning, setQASpecWarning] = useState('');
  const [highlightQASpecRow, setHighlightQASpecRow] = useState(false);
// const hasSpecFiles = specFiles.some(file => !!file);

  // Sample file configuration
  const handleAddSampleFileInput = () => {
    if (!sampleFiles[specFiles.length - 1]) {
      setSampleWarning('** Please upload a file before adding another **');
      return;
    }
    setSampleWarning('');
    setSampleFileInputs(prev => [...prev, prev.length]);
    setSampleFiles(prev => [...prev, null]);
  };


  const handleRemoveSampleFileInput = (idx) => {
    setSampleFileInputs(prev => prev.filter((_, i) => i !== idx));
    setSampleFiles(prev => prev.filter((_, i) => i !== idx));
    setFiles(prev => {
      const updated = { ...prev };
      if (updated.samplePath) {
        updated.samplePath = updated.samplePath.filter((_, i) => i !== idx);
      }
      return updated;
    });
    setSampleWarning('');
  };


  const handleSampleFileChange = (e, idx) => {
    const file = e.target.files[0];
   
    setSampleFiles(prev => {
      const updated = [...prev];
      updated[idx] = file;
      return updated;
    });
    setFiles(prev => ({
      ...prev,
      samplePath: [
        ...(prev.samplePath || []).slice(0, idx),
        file,
        ...(prev.samplePath || []).slice(idx + 1)
      ]
    }));
    setSampleWarning('');
  };

  // Specification files configuration
  const handleAddSpecFileInput = () => {
    if (!specFiles[specFiles.length - 1]) {
      setSpecWarning('** Please upload a file before adding another **');
      return;
    }
    setSpecWarning('');
    setSpecFileInputs(prev => [...prev, prev.length]);
    setSpecFiles(prev => [...prev, null]);
  };

  const handleSpecFileChange = (e, idx) => {
    const file = e.target.files[0];
    
    setSpecFiles(prev => {
      const updated = [...prev];
      updated[idx] = file;
      return updated;
    });
    setFiles(prev => ({
      ...prev,
      specPath: [
        ...(prev.specPath || []).slice(0, idx),
        file,
        ...(prev.specPath || []).slice(idx + 1)
      ]
    }));
    setSpecWarning('');
  };

  const handleRemoveSpecFileInput = (idx) => {
    setSpecFileInputs(prev => prev.filter((_, i) => i !== idx));
    setSpecFiles(prev => prev.filter((_, i) => i !== idx));
    setFiles(prev => {
      const updated = { ...prev };
      if (updated.specPath) {
        updated.specPath = updated.specPath.filter((_, i) => i !== idx);
      }
      return updated;
    });
    setSpecWarning('');
  };

  const handleQaSpecFileChange = (e, idx) => {
    const file = e.target.files[0];
    setQaSpecFiles(prev => {
      const updated = [...prev];
      updated[idx] = file;
      return updated;
    });
    setFiles(prev => ({
      ...prev,
      qaSpecPath: [
        ...(prev.qaSpecPath || []).slice(0, idx),
        file,
        ...(prev.qaSpecPath || []).slice(idx + 1)
      ]
    }));
    setSpecWarning('');
  };

  const handleAddQaSpecFileInput = () => {
    setQaSpecFileInputs(prev => [...prev, Date.now()]);
    setQaSpecFiles(prev => [...prev, null]);
  };

  const handleRemoveQaSpecFileInput = (idx) => {
    setQaSpecFileInputs(prev => prev.filter((_, i) => i !== idx));
    setQaSpecFiles(prev => prev.filter((_, i) => i !== idx));
  };


  const handleInputChange = (e) => {
    const belowSpecFields = [
      "protocol", "as2Id", "endpoint", "ssl", "payloadType", "encryptionAlgo", "signingAlgo", "mdnMode",
      "exchangeCert", "signingCert", "ssid", "sfid", "oftp2Password", "host", "port", "oftp2Cert",
      "username", "authType", "sftpPassword", "directory","envSame",
    ];
    const { name, value } = e.target;

    if (belowSpecFields.includes(name) && checkSpecFileRequired()) {
      return;
    }

    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const checkSpecFileRequired = () => {
    if (specFiles.length > 1 && !specFiles[specFiles.length - 1]) {
      setSpecWarning('Add specification');
      setHighlightSpecRow(true);
      return true;
    }
    setSpecWarning('');
    setHighlightSpecRow(false);
    return false;
  };

  // const handleFileChange = (e) => {
  //   const { name, files: fileList } = e.target;
  //   setFiles(prev => ({
  //     ...prev,
  //     [name]: Array.from(fileList)
  //   }));
  // };

const handleFileChange = (e) => {
  const { name, files } = e.target;
  setFormData(prev => ({
    ...prev,
    [name]: files && files.length > 0 ? files[0] : null
  }));
};

  const handleAddQASampleFileInput = () => {
    setQaSampleFileInputs(prev => [...prev, Date.now()]);
    setQaSampleFiles(prev => [...prev, null]);
  };

  // const handleRemoveQASampleFileInput = (index) => {
  //   setQaSampleFileInputs(inputs => inputs.filter((_, i) => i !== index));
  //   setQaSampleFiles(files => files.filter((_, i) => i !== index));
  // };

  const handleRemoveQASampleFileInput = (idx) => {
    setQaSampleFileInputs(prev => prev.filter((_, i) => i !== idx));
    setQaSampleFiles(prev => prev.filter((_, i) => i !== idx));
  };

  // const handleQASampleFileChange = (e, index) => {
  //   const file = e.target.files[0];
  //   setQaSampleFiles(files => {
  //     const updated = [...files];
  //     updated[index] = file;
  //     return updated;
  //   });
  //   setHighlightQASampleRow(false);
  //   setQASampleWarning('');
  // };

  const handleQASampleFileChange = (e, idx) => {
    const file = e.target.files[0];
    setQaSampleFiles(prev => {
      const updated = [...prev];
      updated[idx] = file;
      return updated;
    });
    setFiles(prev => ({
      ...prev,
      qaSamplePath: [
        ...(prev.qaSamplePath || []).slice(0, idx),
        file,
        ...(prev.qaSamplePath || []).slice(idx + 1)
      ]
    }));
    setQASampleWarning('');
  };






  const handleSubmit = async (e) => {
    
    
    // e.preventDefault();
    const data = new FormData();

    for (const key in formData) {
      data.append(key, formData[key]);
    }

    for (const key in files) {
      const fileList = files[key];
      if (Array.isArray(fileList)) {
        fileList.forEach((file) => {
          data.append(key, file);
        });
      } else {
        data.append(key, fileList);
      }
    }

    try {
      await axios.post('http://localhost:8080/api/partner', data);
      alert('Partner data submitted successfully!');
      window.location.reload();
     

      // remove the data from the form
      // for (const key in formData) {
      //   formData[key] = '';
      // }
      // for (const key in files) {
      //   files[key] = '';
      // }
    } catch (error) {
      console.error('Error submitting form:', error);
      alert('Submission failed!');
    }
  };

  // adding file name preview function

  const getFileNameOrValue = function(input) {
    if (input instanceof File) {
      return input.name;
    } else if (typeof input === 'string' && input.trim() !== '') {
      return input;
    } else {
      return 'No';
    }
  }


  const renderFileList = function(files) {
    if (!files || !files.some(f => f)) {
      return null;
    }
  
    return (
      <ul style={{ margin: 0, paddingLeft: 20 }}>
        {files.map((file, index) =>
          file ? (
            <li key={index}>{file.name || (typeof file === 'string' ? file : '')}</li>
          ) : null
        )}
      </ul>
    );
  }

  const { protocol, ssl, authType } = formData;

  return {
  
    formData,
    setFormData,
    specFileInputs,
    specFiles,
    qaSpecFileInputs,
    qaSpecFiles,
    envSame,
    setEnvSame,
    envTab,
    setEnvTab,
    protocol,
    ssl,
    authType,
    sampleFileInputs,
    sampleFiles,
    setHighlightSampleRow,
    sampleWarning,
    setSampleWarning,
    highlightSampleRow,
    highlightSpecRow,
    setHighlightSpecRow,
    specWarning,
    qaSampleFileInputs,
    qaSampleFiles,
    qaSampleWarning,
    // hasSpecFiles,
    setQASampleWarning,
    highlightQASampleRow,
    setHighlightQASampleRow,
    qaSpecWarning,
    setQASpecWarning,
    highlightQASpecRow,
    setHighlightQASpecRow,
    handleAddQASampleFileInput,
    handleRemoveQASampleFileInput,
    handleQASampleFileChange,
    setSpecWarning,
    handleAddSpecFileInput,
    handleSpecFileChange,
    handleRemoveSpecFileInput,
    handleQaSpecFileChange,
    handleAddQaSpecFileInput,
    handleRemoveQaSpecFileInput,
    handleInputChange,
    handleFileChange,
    handleSubmit,
    handleAddSampleFileInput,
    handleRemoveSampleFileInput,
    handleSampleFileChange,

    getFileNameOrValue,
    renderFileList,
  };
};

export default usePartnerForm;