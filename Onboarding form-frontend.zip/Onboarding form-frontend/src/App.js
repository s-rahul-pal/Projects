import './App.css';
import React from 'react';
import PartnerForm from './components/PartnerForm';


function App() {
  return (
<div className="App">
<PartnerForm />
</div>
  );
}

export default App;
