import React, { useState, useEffect } from "react";
import "./App.css";
import axios from 'axios';

function App() {
  const [currentTime, setCurrentTime] = useState("");
  const [form, setForm] = useState({
    senderId: "",
    receiverId: "",
    idoc: "",
    referenceNo: "",
    dateFrom: "",
    dateTo: "",
    timeFrom: "",
    timeTo: "",
  });
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(now.toLocaleTimeString());
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    const data = new FormData();
    Object.entries(form).forEach(([key, value]) => {
      data.append(key, value);
    });

    try {
      // Change endpoint to your backend search API
      const response = await axios.post('http://localhost:8080/api/partner/search', data);
      setResults(response.data); // response.data should be an array of records
    } catch (error) {
      console.error('Error fetching records:', error);
      alert('Search failed!');
      setResults([]);
    }

    setLoading(false);
  };

  return (
    <div className="container">
      <header className="header">
        <div className="logo">
          <span className="logo-text">TE</span>
        </div>
        <div className="welcome">
          Welcome<br />
          <span className="time">{currentTime}</span>
        </div>
      </header>
      <main className="main-content">
        <h2 className="search-title">Search Options</h2>
        <form className="search-form" onSubmit={handleSubmit}>
          <div className="row">
            <input
              type="text"
              placeholder="Sender Id"
              name="senderId"
              value={form.senderId}
              onChange={handleChange}
            />
            <input
              type="text"
              placeholder="Receiver Id"
              name="receiverId"
              value={form.receiverId}
              onChange={handleChange}
            />
            <input
              type="text"
              placeholder="IDoc"
              name="idoc"
              value={form.idoc}
              onChange={handleChange}
            />
            <input
              type="text"
              placeholder="Reference No."
              name="referenceNo"
              value={form.referenceNo}
              onChange={handleChange}
            />
          </div>
          <div className="row">
            <div className="date-group">
              <label>From</label>
              <input
                type="date"
                name="dateFrom"
                value={form.dateFrom}
                onChange={handleChange}
              />
              <label>To</label>
              <input
                type="date"
                name="dateTo"
                value={form.dateTo}
                onChange={handleChange}
              />
            </div>
            <div className="time-group">
              <label>From</label>
              <input
                type="time"
                name="timeFrom"
                value={form.timeFrom}
                onChange={handleChange}
              />
              <label>To</label>
              <input
                type="time"
                name="timeTo"
                value={form.timeTo}
                onChange={handleChange}
              />
            </div>
          </div>
          <button type="submit" className="submit-btn" disabled={loading}>
            {loading ? "Searching..." : "SUBMIT"}
          </button>
        </form>
        <h2 className="results-title">Search Results</h2>
        <div className="results-table">
          <div className="table-header">
            <span>REFERENCE</span>
            <span>DATE</span>
            <span>STATUS</span>
            <span>BP ID</span>
            <span>SENDER ID</span>
            <span>RECEIVER ID</span>
            <span>CONTROL</span>
            <span>IDOC</span>
            <span>ALA</span>
            <span>BACKUP FILE</span>
          </div>
          {results.length === 0 ? (
            <div className="table-row">
              <span style={{ textAlign: "center", width: "100%" }}>
                {loading ? "Loading..." : "No records found"}
              </span>
            </div>
          ) : (
            results.map((row, idx) => (
              <div className="table-row" key={idx}>
                <span>{row.reference}</span>
                <span>{row.date}</span>
                <span>{row.status}</span>
                <span>{row.bpId}</span>
                <span>{row.senderId}</span>
                <span>{row.receiverId}</span>
                <span>{row.control}</span>
                <span>{row.idoc}</span>
                <span>{row.ala}</span>
                <span>{row.backupFile}</span>
              </div>
            ))
          )}
        </div>
        <div className="download-section">
          <button className="download-btn">DOWNLOAD RESULT</button>
          <div className="copyright">
            Copyright ©2024, Developed by TE Connectivity
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;